/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Tv, 
  Activity, 
  Search, 
  RefreshCw, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  CheckCircle2, 
  AlertTriangle, 
  Flame, 
  Clock, 
  TrendingUp,
  SearchCode,
  Sliders,
  Copy,
  Check,
  ShieldCheck,
  Zap,
  ChevronDown,
  ExternalLink,
  Link2,
  Sun,
  Moon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Hls from 'hls.js';
// @ts-ignore
import mpegts from 'mpegts.js';

interface Match {
  id: string;
  homeTeam: string;
  awayTeam: string;
  homeLogo: string;
  awayLogo: string;
  homeScore: number | null;
  awayScore: number | null;
  league: string;
  status: 'LIVE' | 'UPCOMING' | 'FINISHED';
  time: string;
  channelId?: number | null;
  channelName?: string;
  streamUrl?: string | null;
  qualities?: { quality: string; streamId: number | string; streamUrl: string; name?: string; }[];
}

interface IPTVChannel {
  id: number;
  name: string;
  logo: string;
  category: string;
  streamUrl: string;
  containerExtension?: string;
  qualities?: { quality: string; streamId: number | string; streamUrl: string; containerExtension?: string; name?: string; }[];
}

export default function App() {
  // Helper to safely format match time strings
  const formatDisplayTime = (timeVal: any): string => {
    if (timeVal === null || timeVal === undefined) return 'اليوم';
    if (typeof timeVal === 'string') return timeVal;
    if (typeof timeVal === 'number') return `${timeVal}'`;
    if (typeof timeVal === 'object') {
      if (timeVal.minute !== undefined) {
        return `${timeVal.minute}${timeVal.extra ? '+' + timeVal.extra : ''}'`;
      }
      if (timeVal.time !== undefined && typeof timeVal.time !== 'object') {
        return String(timeVal.time);
      }
      if (timeVal.type) return String(timeVal.type);
      try {
        return JSON.stringify(timeVal);
      } catch (e) {
        return 'مباشر';
      }
    }
    return String(timeVal);
  };

  const [matches, setMatches] = useState<Match[]>([]);
  const [channels, setChannels] = useState<IPTVChannel[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [activeMatch, setActiveMatch] = useState<Match | null>(null);
  const [activeChannel, setActiveChannel] = useState<IPTVChannel | null>(null);
  const [currentStreamUrl, setCurrentStreamUrl] = useState<string>('');
  const [isLoadingMatches, setIsLoadingMatches] = useState(true);
  const [isLoadingChannels, setIsLoadingChannels] = useState(true);
  const [matchesError, setMatchesError] = useState<string | null>(null);
  const [channelsError, setChannelsError] = useState<string | null>(null);
  const [isLoadingStream, setIsLoadingStream] = useState(false);
  const [streamError, setStreamError] = useState<string | null>(null);
  const [isBuffering, setIsBuffering] = useState(false);
  const [onlyShowSd, setOnlyShowSd] = useState(false);
  const [showSdPrompt, setShowSdPrompt] = useState(false);
  const [detectedSdQuality, setDetectedSdQuality] = useState<{ quality: string; streamId: number | string; streamUrl: string; } | null>(null);
  const bufferEventsRef = useRef<number[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [activeTab, setActiveTab] = useState<'all-channels' | 'live-matches'>('live-matches');
  const [showSettings, setShowSettings] = useState(false);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [isM3uLoaded, setIsM3uLoaded] = useState(false);
  const [m3uFileName, setM3uFileName] = useState('');
  const [customUrl, setCustomUrl] = useState('');

  // Handle custom pasted HLS stream (.m3u8) URL
  const handlePlayCustomUrl = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = customUrl.trim();
    if (!trimmed) return;

    let finalStreamUrl = trimmed;
    if (!trimmed.startsWith('/api/proxy') && (trimmed.startsWith('http://') || trimmed.startsWith('https://'))) {
      finalStreamUrl = `/api/proxy?url=${encodeURIComponent(trimmed)}`;
    }

    const customChannelObj: IPTVChannel = {
      id: Date.now(),
      name: 'بث خارجي مباشر (Custom Stream)',
      logo: '',
      category: 'مخصص',
      streamUrl: finalStreamUrl,
      containerExtension: trimmed.split('?')[0].split('.').pop() || 'm3u8',
      qualities: [
        {
          quality: 'المباشر',
          streamId: 'custom_quality',
          streamUrl: finalStreamUrl
        }
      ]
    };

    setActiveMatch(null);
    setActiveChannel(customChannelObj);
    handlePlayStream(finalStreamUrl, customChannelObj.name);
  };

  // Client-side M3U Parser
  const handleM3uUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setM3uFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (!text) return;

      const lines = text.split('\n');
      const parsedChannels: IPTVChannel[] = [];
      let currentChannel: Partial<IPTVChannel> = {};

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (line.startsWith('#EXTINF:')) {
          const nameMatch = line.match(/,(.+)$/);
          const logoMatch = line.match(/tvg-logo="([^"]+)"/);
          const groupMatch = line.match(/group-title="([^"]+)"/);

          currentChannel.name = nameMatch ? nameMatch[1].trim() : 'Unknown Channel';
          currentChannel.logo = logoMatch ? logoMatch[1] : '';
          currentChannel.category = groupMatch ? groupMatch[1] : 'M3U Channel';
          currentChannel.id = Math.floor(Math.random() * 1000000);
        } else if (line.startsWith('http')) {
          currentChannel.streamUrl = `/api/proxy?url=${encodeURIComponent(line)}`;
          if (currentChannel.name) {
            parsedChannels.push(currentChannel as IPTVChannel);
          }
          currentChannel = {};
        }
      }

      if (parsedChannels.length > 0) {
        setChannels(parsedChannels);
        setIsM3uLoaded(true);
        setActiveChannel(parsedChannels[0]);
        handlePlayStream(parsedChannels[0].streamUrl, parsedChannels[0].name);
      }
    };
    reader.readAsText(file);
  };

  // Custom credentials display states
  const [iptvServer, setIptvServer] = useState("http://cf.business-cdn-8k.com");
  const [iptvUser, setIptvUser] = useState("fc15a10ddf60");
  const [iptvPass, setIptvPass] = useState("27f05ada66");

  // Input states for custom configuration form
  const [m3uInputUrl, setM3uInputUrl] = useState("");
  const [hostInput, setHostInput] = useState("");
  const [userInput, setUserInput] = useState("");
  const [passInput, setPassInput] = useState("");
  
  const [isUpdatingCreds, setIsUpdatingCreds] = useState(false);
  const [credsMessage, setCredsMessage] = useState<{ text: string; type: 'success' | 'error' | 'warning' | null }>({ text: '', type: null });

  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const mpegtsRef = useRef<any>(null);

  // Fetch current server config from the backend
  const fetchCredentials = async () => {
    try {
      const res = await fetch('/api/iptv/credentials');
      if (res.ok) {
        const data = await res.json();
        setIptvServer(data.host || '');
        setIptvUser(data.username || '');
        setIptvPass(data.password || '');
        
        setHostInput(data.host || '');
        setUserInput(data.username || '');
        setPassInput(data.password || '');
      }
    } catch (err) {
      console.error("Failed to fetch active credentials:", err);
    }
  };

  const handleUpdateCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdatingCreds(true);
    setCredsMessage({ text: 'جاري تحديث بيانات الاتصال والتحقق من الخادم...', type: 'warning' });

    try {
      const res = await fetch('/api/iptv/credentials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          m3uUrl: m3uInputUrl,
          host: hostInput,
          username: userInput,
          password: passInput
        })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setIptvServer(data.credentials.host);
        setIptvUser(data.credentials.username);
        setIptvPass(data.credentials.password);

        setHostInput(data.credentials.host);
        setUserInput(data.credentials.username);
        setPassInput(data.credentials.password);
        setM3uInputUrl(""); // clear link input after successful parse

        setCredsMessage({ 
          text: data.message, 
          type: data.fallback ? 'warning' : 'success' 
        });

        // Instantly reload matching and streams list!
        fetchMatches();
        fetchChannels();
      } else {
        setCredsMessage({ 
          text: data.message || 'فشل تحديث البيانات، يرجى التحقق من المدخلات.', 
          type: 'error' 
        });
      }
    } catch (err: any) {
      setCredsMessage({ 
        text: `حدث خطأ أثناء الاتصال بالخادم: ${err.message}`, 
        type: 'error' 
      });
    } finally {
      setIsUpdatingCreds(false);
    }
  };

  // Initial loads
  useEffect(() => {
    fetchCredentials();
    fetchMatches();
    fetchChannels();
    
    // Auto refresh matches list every 60 seconds
    const interval = setInterval(fetchMatches, 60000);
    return () => {
      clearInterval(interval);
      if (hlsRef.current) {
        hlsRef.current.destroy();
      }
      if (mpegtsRef.current) {
        mpegtsRef.current.destroy();
      }
    };
  }, []);

  const fetchMatches = async (force: boolean = false) => {
    setIsLoadingMatches(true);
    setMatchesError(null);
    try {
      const res = await fetch(`/api/live-matches${force ? '?force=true' : ''}`);
      if (res.ok) {
        const data = await res.json();
        const safeData = Array.isArray(data) ? data : [];
        setMatches(safeData);
        
        // Auto-select first match to play if none is currently playing
        if (safeData.length > 0 && !activeMatch && !activeChannel) {
          const liveMatch = safeData.find((m: Match) => m.status === 'LIVE');
          const matchToPlay = liveMatch || safeData[0];
          setActiveMatch(matchToPlay);
          if (matchToPlay.streamUrl) {
            handlePlayStream(matchToPlay.streamUrl, matchToPlay.homeTeam + ' vs ' + matchToPlay.awayTeam);
          }
        }
      } else {
        setMatchesError('حدث خطأ في جلب المباريات من الخادم.');
      }
    } catch (err: any) {
      console.error("Failed to load matches:", err);
      setMatchesError('تعذر جلب المباريات المباشرة. يرجى تحديث الصفحة.');
    } finally {
      setIsLoadingMatches(false);
    }
  };

  const fetchChannels = async (force: boolean = false) => {
    setIsLoadingChannels(true);
    setChannelsError(null);
    try {
      const res = await fetch(`/api/iptv/channels${force ? '?force=true' : ''}`);
      if (res.ok) {
        const data = await res.json();
        const safeData = Array.isArray(data) ? data : [];
        setChannels(safeData);
        if (safeData.length === 0) {
          setChannelsError('لم يتم استرجاع أي قنوات من خادم IPTV. يرجى التأكد من صحة البيانات.');
        }
      } else {
        setChannelsError('خطأ في جلب القنوات، يرجى تحديث الصفحة أو التحقق من بيانات الاتصال.');
      }
    } catch (err: any) {
      console.error("Failed to load IPTV channels:", err);
      setChannelsError('تعذر الاتصال بخادم القنوات. يرجى التحقق من الخادم وإعادة المحاولة.');
    } finally {
      setIsLoadingChannels(false);
    }
  };

  const handlePlayStream = (url: string, title: string) => {
    if (!url) return;
    setCurrentStreamUrl(url);
    setIsLoadingStream(true);
    setStreamError(null);
    setIsPlaying(false);
    setShowSdPrompt(false);
    setDetectedSdQuality(null);
    bufferEventsRef.current = [];
  };

  // Safe and professional useEffect for player initialization
  useEffect(() => {
    const video = videoRef.current;
    // Add DOM Element Safety Check: Don't initialize player if video ref is not ready in DOM
    if (!video || !currentStreamUrl) return;

    // Clean up any existing player instances before initializing new one
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }
    if (mpegtsRef.current) {
      mpegtsRef.current.destroy();
      mpegtsRef.current = null;
    }

    // Proxy is running relative to window location origin
    const fullProxyUrl = currentStreamUrl.startsWith('http') ? currentStreamUrl : window.location.origin + currentStreamUrl;

    // Direct helper to initialize HLS.js or native HLS player
    const playHlsStream = (streamUrl: string) => {
      console.log("Playing HLS stream using Hls.js:", streamUrl);
      if (Hls.isSupported()) {
        const hls = new Hls({
          maxMaxBufferLength: 10,
          lowLatencyMode: true,
          enableWorker: true,
          backBufferLength: 30,
          xhrSetup: (xhr) => {
            xhr.withCredentials = false;
          }
        });
        hlsRef.current = hls;

        hls.loadSource(streamUrl);
        hls.attachMedia(video);

        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          setIsLoadingStream(false);
          setIsPlaying(true);
          video.play().catch(e => console.log("Autoplay blocked", e));
        });

        hls.on(Hls.Events.ERROR, (event, data) => {
          if (data.fatal) {
            switch (data.type) {
              case Hls.ErrorTypes.NETWORK_ERROR:
                console.warn("HLS network error, attempting recovery...", data);
                hls.startLoad();
                break;
              case Hls.ErrorTypes.MEDIA_ERROR:
                console.warn("HLS media error, recovering...", data);
                hls.recoverMediaError();
                break;
              default:
                setIsLoadingStream(false);
                setStreamError("Failed to play stream. Channel might be temporarily offline.");
                hls.destroy();
                hlsRef.current = null;
                break;
            }
          }
        });
      } 
      else if (video.canPlayType('application/vnd.apple.mpegurl')) {
        video.src = streamUrl;
        const onLoaded = () => {
          setIsLoadingStream(false);
          setIsPlaying(true);
          video.play().catch(e => console.log("Autoplay blocked", e));
          video.removeEventListener('loadedmetadata', onLoaded);
        };
        video.addEventListener('loadedmetadata', onLoaded);
        
        const onError = () => {
          setIsLoadingStream(false);
          setStreamError("Failed to play native HLS stream.");
          video.removeEventListener('error', onError);
        };
        video.addEventListener('error', onError);
      } else {
        setIsLoadingStream(false);
        setStreamError("Your browser does not support HLS streaming.");
      }
    };

    // Direct helper to initialize mpegts.js for raw MPEG-TS continuous streams
    const playTsStream = (streamUrl: string) => {
      console.log("Playing continuous MPEG-TS stream using mpegts.js:", streamUrl);
      if (mpegts.isSupported()) {
        try {
          // Robust custom configuration for stable playback with a 10-second buffer
          const customConfig = {
            enableWorker: true,
            enableStashBuffer: true, // Enable stash buffer for smooth playback and less lag!
            stashInitialSize: 1024, // Increased initial buffer (1MB) to prevent immediate stutter
            liveBufferLatencyChasing: true,
            liveBufferLatencyChasingOnPaused: true,
            liveBufferLatencyMinRemain: 10, // Maintain a solid 10-second delay behind live to prevent lags
            liveBufferLatencyMaxLatency: 15, // Only start latency chasing if delay goes beyond 15 seconds
          };

          const player = mpegts.createPlayer({
            type: 'mse', // MSE engine
            isLive: true,
            url: streamUrl
          }, customConfig);

          mpegtsRef.current = player;
          player.attachMediaElement(video);
          player.load();
          const playPromise = player.play();
          if (playPromise && typeof playPromise.then === 'function') {
            playPromise.then(() => {
              setIsLoadingStream(false);
              setIsPlaying(true);
            }).catch(e => {
              console.error("mpegts.js play failed:", e);
              setIsLoadingStream(false);
              setStreamError("Failed to play the MPEG-TS stream.");
            });
          } else {
            setIsLoadingStream(false);
            setIsPlaying(true);
          }

          player.on(mpegts.Events.ERROR, (type, detail, info) => {
            console.error("mpegts.js error:", type, detail, info);
            setIsLoadingStream(false);
            setStreamError("Failed to load MPEG-TS stream.");
          });
        } catch (error) {
          console.error("Failed advanced mpegts.js configuration. Falling back to safe defaults:", error);
          try {
            // Fallback to safe basic live configuration to prevent freeze/crash
            const safeConfig = {
              enableWorker: false, // Turn off worker if causing issues on certain browsers
              enableStashBuffer: true,
              stashInitialSize: 512,
              isLive: true
            };
            const player = mpegts.createPlayer({
              type: 'mse',
              isLive: true,
              url: streamUrl
            }, safeConfig);

            mpegtsRef.current = player;
            player.attachMediaElement(video);
            player.load();
            const playPromise = player.play();
            if (playPromise && typeof playPromise.then === 'function') {
              playPromise.then(() => {
                setIsLoadingStream(false);
                setIsPlaying(true);
              }).catch(e => {
                console.error("Fallback player play failed:", e);
              });
            } else {
              setIsLoadingStream(false);
              setIsPlaying(true);
            }
          } catch (fallbackError) {
            console.error("Safe fallback initialization also failed:", fallbackError);
            setIsLoadingStream(false);
            setStreamError("Failed to start the video stream safely.");
          }
        }
      } else if (video.canPlayType('video/mp2t')) {
        video.src = streamUrl;
        video.play().then(() => {
          setIsLoadingStream(false);
          setIsPlaying(true);
        }).catch(e => {
          setIsLoadingStream(false);
          setStreamError("Failed to play native TS stream.");
        });
      } else {
        setIsLoadingStream(false);
        setStreamError("MPEG-TS playback is not supported in this browser. Please use Chrome or Firefox.");
      }
    };

    // Find the channel in our loaded channels list to see if we know its container extension
    // Extract streamId or channelId from URL
    const channelIdMatch = currentStreamUrl.match(/\/api\/proxy\/stream\/([^\/?#.]+)/);
    const idFromUrl = channelIdMatch ? channelIdMatch[1] : null;
    
    let knownExtension = '';
    if (idFromUrl) {
      // Find among channels list
      const chan = channels.find(c => String(c.id) === String(idFromUrl));
      if (chan) {
        knownExtension = chan.containerExtension || '';
      } else {
        // Find inside qualities lists
        for (const c of channels) {
          if (c.qualities) {
            const q = c.qualities.find((qi: any) => String(qi.streamId) === String(idFromUrl));
            if (q) {
              knownExtension = q.containerExtension || '';
              break;
            }
          }
        }
      }
    }

    // Zero-Fetch Client Playback: Determine format directly from metadata and play immediately
    const isM3U8 = knownExtension === 'm3u8' || 
                   currentStreamUrl.toLowerCase().includes('.m3u8') || 
                   currentStreamUrl.toLowerCase().includes('.m3u');

    if (isM3U8) {
      console.log(`[Zero-Fetch] Metadata/URL indicates HLS format. Initializing Hls.js directly.`);
      playHlsStream(fullProxyUrl);
    } else {
      console.log(`[Zero-Fetch] Metadata indicates TS format or fallback. Initializing mpegts.js directly.`);
      playTsStream(fullProxyUrl);
    }
  }, [currentStreamUrl, channels]);

  const handleMatchClick = (match: Match) => {
    setActiveChannel(null);
    setActiveMatch(match);
    if (match.streamUrl) {
      handlePlayStream(match.streamUrl, `${match.homeTeam} vs ${match.awayTeam}`);
    } else {
      setStreamError("No mapped channel is currently online for this match.");
    }
  };

  const handleChannelClick = (channel: IPTVChannel) => {
    setActiveMatch(null);
    setActiveChannel(channel);
    
    // If onlyShowSd is active, check if an SD version is available and play it directly
    const sdQuality = channel.qualities?.find(q => q.quality.toUpperCase() === 'SD');
    if (onlyShowSd && sdQuality) {
      handlePlayStream(sdQuality.streamUrl, channel.name);
    } else {
      handlePlayStream(channel.streamUrl, channel.name);
    }
  };

  // Video Controls
  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (isPlaying) {
      video.pause();
      setIsPlaying(false);
    } else {
      video.play().catch(e => console.log(e));
      setIsPlaying(true);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    const video = videoRef.current;
    if (video) {
      video.volume = val;
      video.muted = val === 0;
      setIsMuted(val === 0);
    }
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    const nextMuted = !isMuted;
    video.muted = nextMuted;
    setIsMuted(nextMuted);
    if (nextMuted) {
      video.volume = 0;
    } else {
      video.volume = volume || 0.8;
    }
  };

  const handleFullscreen = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.requestFullscreen) {
      video.requestFullscreen();
    } else if ((video as any).webkitRequestFullscreen) {
      (video as any).webkitRequestFullscreen();
    } else if ((video as any).msRequestFullscreen) {
      (video as any).msRequestFullscreen();
    }
  };

  const reloadStream = () => {
    if (currentStreamUrl) {
      handlePlayStream(currentStreamUrl, activeMatch ? `${activeMatch.homeTeam} vs ${activeMatch.awayTeam}` : (activeChannel?.name || 'Stream'));
    }
  };

  const handleBufferingDetected = () => {
    setIsBuffering(true);
    
    // Get SD quality if available for current stream
    const qualities = activeMatch ? activeMatch.qualities : activeChannel?.qualities;
    if (!qualities) return;
    
    const sdQ = qualities.find(q => q.quality.toUpperCase() === 'SD' || q.name?.toLowerCase().includes('sd'));
    if (!sdQ) return;
    
    // Check if we are already playing this SD version
    if (currentStreamUrl === sdQ.streamUrl) return;
    
    // Add timestamp to buffer event history
    const now = Date.now();
    const windowMs = 30000; // 30 seconds window
    const history = [...bufferEventsRef.current, now].filter(t => now - t < windowMs);
    bufferEventsRef.current = history;
    
    console.log(`[Lag Monitor] Buffer events in last 30s: ${history.length}/3`);
    
    // If buffering count >= 3 in last 30 seconds, trigger SD switch prompt!
    if (history.length >= 3) {
      setDetectedSdQuality({
        quality: sdQ.quality,
        streamId: sdQ.streamId,
        streamUrl: sdQ.streamUrl
      });
      setShowSdPrompt(true);
      // Reset history so we don't spam prompt immediately again
      bufferEventsRef.current = [];
    }
  };

  const handleSwitchToSd = () => {
    if (detectedSdQuality) {
      handlePlayStream(detectedSdQuality.streamUrl, activeMatch ? `${activeMatch.homeTeam} vs ${activeMatch.awayTeam}` : activeChannel?.name || '');
      setShowSdPrompt(false);
    }
  };

  const copyToClipboard = () => {
    const fullUrl = currentStreamUrl.startsWith('http') ? currentStreamUrl : window.location.origin + currentStreamUrl;
    navigator.clipboard.writeText(fullUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  // Filter channels based on categories and search query
  const filteredChannels = (channels || []).filter(channel => {
    if (!channel) return false;
    const query = searchQuery.toLowerCase();
    const nameSafe = channel.name || '';
    const matchesSearch = nameSafe.toLowerCase().includes(query) ||
                          (channel.qualities && channel.qualities.some(q => (q.name || '').toLowerCase().includes(query) || (q.quality || '').toLowerCase().includes(query)));
    
    // Filter by SD quality if checked
    if (onlyShowSd) {
      const hasSdQuality = channel.qualities && channel.qualities.some(q => q.quality.toUpperCase() === 'SD');
      if (!hasSdQuality) return false;
    }

    if (selectedCategory === 'All') return matchesSearch;
    if (selectedCategory === 'beIN') return matchesSearch && nameSafe.toLowerCase().includes('bein');
    if (selectedCategory === 'SSC') return matchesSearch && nameSafe.toLowerCase().includes('ssc');
    if (selectedCategory === 'Arryadia') return matchesSearch && (nameSafe.toLowerCase().includes('arryadia') || nameSafe.toLowerCase().includes('ryadia') || nameSafe.includes('رياضية'));
    if (selectedCategory === 'Canal+') return matchesSearch && (nameSafe.toLowerCase().includes('canal') || nameSafe.toLowerCase().includes('rmc'));
    return matchesSearch;
  });

  // Initials generator for team badges if logo is broken
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .slice(0, 2)
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };

  // Helper colors for initials fallbacks
  const getInitialsColor = (name: string) => {
    const colors = [
      'from-blue-600 to-indigo-600',
      'from-emerald-600 to-teal-600',
      'from-rose-600 to-red-600',
      'from-purple-600 to-indigo-600',
      'from-amber-600 to-orange-600',
      'from-cyan-600 to-blue-600',
    ];
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    const index = Math.abs(hash) % colors.length;
    return colors[index];
  };

  return (
    <div id="iptv_app" className={theme === 'dark' ? 'min-h-screen bg-[#070914] text-slate-100 flex flex-col font-sans antialiased selection:bg-purple-600 selection:text-white transition-colors duration-300' : 'min-h-screen bg-slate-100 text-slate-800 flex flex-col font-sans antialiased selection:bg-purple-600 selection:text-white light transition-colors duration-300'}>
      {/* Background radial lights */}
      <div className={theme === 'dark' ? 'absolute top-0 left-0 right-0 h-[500px] bg-gradient-to-b from-purple-900/20 via-transparent to-transparent pointer-events-none z-0' : 'absolute top-0 left-0 right-0 h-[500px] bg-gradient-to-b from-purple-100/60 via-transparent to-transparent pointer-events-none z-0'} />
      <div className={theme === 'dark' ? 'absolute bottom-0 right-0 w-[500px] h-[500px] bg-gradient-to-t from-indigo-950/20 via-transparent to-transparent pointer-events-none z-0' : 'absolute bottom-0 right-0 w-[500px] h-[500px] bg-gradient-to-t from-indigo-100/40 via-transparent to-transparent pointer-events-none z-0'} />

      {/* Header */}
      <header className={theme === 'dark' ? 'border-b border-slate-800/80 bg-[#080B17]/95 sticky top-0 z-40 px-6 py-4 backdrop-blur shadow-lg shadow-black/20' : 'border-b border-slate-200 bg-white/95 sticky top-0 z-40 px-6 py-4 backdrop-blur shadow-xs'}>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-purple-500/20">
              <Tv className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h1 className={`text-lg font-black tracking-tight flex items-center gap-2 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                ماجد لايف <span className="text-purple-500 font-bold">| Majid Live Stream</span>
              </h1>
              <p className={`text-xs ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>
                لوحة البث التلقائي الذكية للمباريات والرياضة عبر نظام Proxy آمن
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 text-xs font-semibold glow-emerald">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              CORS PROXY ACTIVE
            </span>
            <button 
              onClick={() => { fetchMatches(true); fetchChannels(true); }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition duration-200 cursor-pointer text-xs ${
                theme === 'dark' 
                  ? 'bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border-slate-800' 
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 border-slate-200'
              }`}
            >
              <RefreshCw className="w-3.5 h-3.5" />
              تحديث البيانات
            </button>
            <button 
              onClick={() => setShowSettings(!showSettings)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition duration-200 cursor-pointer text-xs font-medium ${
                theme === 'dark'
                  ? 'bg-purple-950/40 hover:bg-purple-900/40 text-purple-300 hover:text-purple-200 border-purple-900/30'
                  : 'bg-purple-50 hover:bg-purple-100 text-purple-700 hover:text-purple-800 border-purple-200'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              الاشتراك النشط
            </button>
            <button 
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className={`p-2 rounded-xl border transition duration-200 cursor-pointer text-xs ${
                theme === 'dark'
                  ? 'bg-slate-900 hover:bg-slate-800 text-amber-400 border-slate-800'
                  : 'bg-slate-100 hover:bg-slate-200 text-indigo-600 border-slate-200'
              }`}
              title={theme === 'dark' ? 'تغيير إلى المظهر الفاتح' : 'تغيير إلى المظهر الداكن'}
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Settings Panel */}
      <AnimatePresence>
        {showSettings && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-[#0b0f24] border-b border-slate-800 overflow-hidden z-30"
          >
            <div className="max-w-7xl mx-auto px-6 py-6">
              <h2 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-purple-400" />
                إعدادات خادم IPTV ومصادقة الاشتراكات
              </h2>

              <form onSubmit={handleUpdateCredentials} className="space-y-4">
                {/* Option 1: Paste M3U Link */}
                <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-850">
                  <label className="block text-xs font-bold text-slate-300 mb-1.5">
                    الخيار الأول: أدخل رابط M3U كامل (سيتم استخراج البيانات والروابط تلقائياً)
                  </label>
                  <input
                    type="text"
                    placeholder="http://domain.com/get.php?username=XXX&password=YYY&output=ts"
                    value={m3uInputUrl}
                    onChange={(e) => setM3uInputUrl(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none transition font-mono"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    انسخ رابط ملف الـ M3U الخاص باشتراكك هنا وسيقوم النظام تلقائياً باستخلاص عنوان الخادم، اسم المستخدم وكلمة المرور.
                  </p>
                </div>

                {/* Option 2: Xtream Codes direct fields */}
                <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-850">
                  <label className="block text-xs font-bold text-slate-300 mb-2">
                    الخيار الثاني: أدخل بيانات Xtream Codes يدوياً
                  </label>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">HOST URL (عنوان الخادم)</span>
                      <input
                        type="text"
                        placeholder="http://cf.business-cdn-8k.com"
                        value={hostInput}
                        onChange={(e) => setHostInput(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none transition font-mono"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">USERNAME (اسم المستخدم)</span>
                      <input
                        type="text"
                        placeholder="5d379e92a293"
                        value={userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none transition font-mono"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">PASSWORD (كلمة المرور)</span>
                      <input
                        type="password"
                        placeholder="34ef08a94847"
                        value={passInput}
                        onChange={(e) => setPassInput(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none transition font-mono"
                      />
                    </div>
                  </div>
                </div>

                {/* Status and Action Buttons */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
                  <div className="w-full sm:w-auto">
                    {credsMessage.text && (
                      <div className={`px-4 py-2 rounded-xl text-xs flex items-center gap-2 border ${
                        credsMessage.type === 'success' 
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                          : credsMessage.type === 'warning' 
                            ? 'bg-amber-500/10 text-amber-400 border-amber-500/20 animate-pulse'
                            : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                      }`}>
                        <ShieldCheck className="w-4 h-4 shrink-0" />
                        <span>{credsMessage.text}</span>
                      </div>
                    )}
                  </div>

                  <button
                    type="submit"
                    disabled={isUpdatingCreds}
                    className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold transition shadow-lg disabled:opacity-50 cursor-pointer"
                  >
                    {isUpdatingCreds ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <Check className="w-4 h-4" />
                    )}
                    حفظ وتحديث الاتصال بالخادم
                  </button>
                </div>
              </form>

              {/* Active Credentials Summary Row */}
              <div className="mt-5 pt-4 border-t border-slate-800/60 grid grid-cols-1 sm:grid-cols-3 gap-4 text-[11px] text-slate-400">
                <div>الخادم النشط: <span className="text-purple-300 font-mono">{iptvServer}</span></div>
                <div>اسم المستخدم: <span className="text-purple-300 font-mono">{iptvUser}</span></div>
                <div>كلمة المرور: <span className="text-purple-300 font-mono">•••••••• ({iptvPass})</span></div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 grid grid-cols-1 lg:grid-cols-12 gap-8 z-10 relative">
        
        {/* Left Column: Video Stage + Bottom Details */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          
          {/* Active Stream Panel / Video Container */}
          <div className="glass-panel rounded-3xl overflow-hidden shadow-2xl shadow-black/80 border border-slate-800/80 glow-purple">
            <div className="relative aspect-video bg-black flex items-center justify-center group overflow-hidden">
              <video 
                ref={videoRef}
                className="w-full h-full object-contain"
                playsInline
                onClick={togglePlay}
                onPlaying={() => {
                  setIsLoadingStream(false);
                  setIsBuffering(false);
                  setIsPlaying(true);
                }}
                onWaiting={handleBufferingDetected}
                onCanPlay={() => {
                  setIsLoadingStream(false);
                  setIsBuffering(false);
                }}
                onTimeUpdate={() => {
                  if (isLoadingStream) setIsLoadingStream(false);
                  if (isBuffering) setIsBuffering(false);
                }}
              />

              {/* Dynamic Fallback to SD Toast Overlay */}
              <AnimatePresence>
                {showSdPrompt && detectedSdQuality && (
                  <motion.div 
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 15 }}
                    className="absolute bottom-16 left-4 right-4 md:left-6 md:right-6 bg-slate-950/95 backdrop-blur-md border border-amber-500/40 p-4 rounded-2xl shadow-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 z-30 pointer-events-auto"
                  >
                    <div className="flex items-start gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400 shrink-0 mt-0.5">
                        <AlertTriangle className="w-4 h-4 text-amber-500 animate-bounce" />
                      </div>
                      <div className="text-right">
                        <h4 className="text-xs font-black text-white">رصد تقطيع مستمر في البث المباشر</h4>
                        <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">
                          نظام الكشف الذكي رصد تقطيعاً متكرراً. تتوفر جودة منخفضة <span className="text-amber-400 font-bold">SD (Low Quality)</span> قد توفر بثاً أكثر استقراراً.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                      <button
                        onClick={handleSwitchToSd}
                        className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-[10px] font-black transition shadow-lg cursor-pointer flex items-center gap-1"
                      >
                        <Zap className="w-3 h-3 fill-slate-950" />
                        التحويل إلى SD الآن
                      </button>
                      <button
                        onClick={() => setShowSdPrompt(false)}
                        className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 text-[10px] font-bold transition cursor-pointer"
                      >
                        تجاهل
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Buffering Indicator (subtle overlay on top of active video, no full solid background) */}
              {isBuffering && !isLoadingStream && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/35 pointer-events-none z-10">
                  <div className="bg-slate-950/85 backdrop-blur-md px-5 py-3 rounded-2xl border border-purple-500/25 shadow-2xl flex items-center gap-3">
                    <RefreshCw className="w-4 h-4 text-purple-400 animate-spin" />
                    <span className="text-xs font-bold text-slate-200">جاري التخزين المؤقت... (Buffering)</span>
                  </div>
                </div>
              )}

              {/* Custom loader / buffering overlay */}
              {isLoadingStream && (
                <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center gap-4 z-10">
                  <div className="relative flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full border-4 border-purple-500/20 border-t-purple-500 animate-spin" />
                    <Zap className="w-6 h-6 text-purple-400 absolute animate-pulse" />
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-bold text-white tracking-wide">جاري فك تشفير وتخطي جدار الحماية...</p>
                    <p className="text-xs text-slate-400 mt-1.5 font-mono">Bypassing CORS & Fetching HLS payload</p>
                  </div>
                </div>
              )}

              {/* Stream Error display */}
              {streamError && !isLoadingStream && (
                <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center p-6 text-center z-10">
                  <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 mb-4">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <h4 className="text-base font-bold text-white mb-2">تعذر تشغيل دفق الفيديو المباشر</h4>
                  <p className="text-xs text-slate-400 max-w-md leading-relaxed mb-6">
                    {streamError}
                  </p>
                  <button 
                    onClick={reloadStream}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-xs font-semibold text-white transition cursor-pointer"
                  >
                    <RefreshCw className="w-4 h-4" />
                    إعادة محاولة الاتصال بالخادم
                  </button>
                </div>
              )}

              {/* HTML5 video elements controls overlay */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent p-4 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-between z-20">
                <div className="flex items-center gap-3">
                  <button 
                    onClick={togglePlay}
                    className="w-10 h-10 rounded-xl bg-purple-600 hover:bg-purple-500 text-white flex items-center justify-center transition shadow-lg cursor-pointer"
                  >
                    {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-white" />}
                  </button>
                  <button 
                    onClick={reloadStream}
                    className="w-10 h-10 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 flex items-center justify-center border border-slate-800 transition cursor-pointer"
                    title="Reload Stream"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>

                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={toggleMute}
                      className="text-slate-300 hover:text-white transition cursor-pointer"
                    >
                      {isMuted ? <VolumeX className="w-5 h-5 text-purple-400" /> : <Volume2 className="w-5 h-5" />}
                    </button>
                    <input 
                      type="range" 
                      min="0" 
                      max="1" 
                      step="0.05" 
                      value={isMuted ? 0 : volume} 
                      onChange={handleVolumeChange}
                      className="w-20 accent-purple-500 cursor-pointer"
                    />
                  </div>
                  <button 
                    onClick={handleFullscreen}
                    className="text-slate-300 hover:text-white transition cursor-pointer"
                    title="Fullscreen"
                  >
                    <Maximize className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Currently Playing Metadata Bar */}
            <div className={`p-5 sm:p-6 border-t flex flex-col md:flex-row md:items-center justify-between gap-5 ${
              theme === 'dark' ? 'bg-[#0a0d1e]/90 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}>
              <div className="space-y-1.5 flex-grow">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-red-500 text-white font-black text-[10px] tracking-wider animate-pulse">
                    LIVE
                  </span>
                  <h3 className={`text-base font-extrabold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                    {activeMatch ? `${activeMatch.homeTeam} vs ${activeMatch.awayTeam}` : (activeChannel ? activeChannel.name : 'لم يتم تحديد بث')}
                  </h3>
                </div>
                <p className={`text-xs flex items-center gap-1 ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>
                  <Activity className="w-3.5 h-3.5 text-purple-500" />
                  {activeMatch ? activeMatch.league : (activeChannel ? 'قناة تلفزيونية رياضية' : 'الرجاء اختيار مباراة أو قناة لمشاهدة البث المباشر')}
                </p>

                {/* Intelligent quality switching selector */}
                {(() => {
                  const qualities = activeMatch ? activeMatch.qualities : (activeChannel ? activeChannel.qualities : undefined);
                  if (qualities && qualities.length > 1) {
                    return (
                      <div className={`flex flex-wrap items-center gap-2 mt-3 pt-3 border-t ${theme === 'dark' ? 'border-slate-800/50' : 'border-slate-200'}`}>
                        <span className={`text-[10px] font-bold flex items-center gap-1 font-mono ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>
                          <Sliders className="w-3.5 h-3.5 text-purple-500 animate-pulse" />
                          اختيار الجودة:
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {qualities.map((q) => {
                            const isActive = currentStreamUrl === q.streamUrl;
                            return (
                              <button
                                key={q.streamId}
                                onClick={() => {
                                  handlePlayStream(q.streamUrl, activeMatch ? `${activeMatch.homeTeam} vs ${activeMatch.awayTeam}` : activeChannel?.name || '');
                                }}
                                className={`px-2.5 py-1 rounded-lg text-[10px] font-black transition cursor-pointer border ${
                                  isActive
                                    ? 'bg-purple-600 text-white border-purple-500 shadow-lg shadow-purple-500/20'
                                    : theme === 'dark'
                                      ? 'bg-slate-900 hover:bg-slate-850 text-slate-400 border-slate-800'
                                      : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                                }`}
                              >
                                {q.quality}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    );
                  }
                  return null;
                })()}
              </div>

              {/* Dev metadata proxy details */}
              <div className={`flex flex-col items-end gap-1.5 w-full md:w-auto border-t md:border-t-0 pt-3 md:pt-0 ${theme === 'dark' ? 'border-slate-800' : 'border-slate-200'}`}>
                <span className="text-xs text-indigo-500 font-bold bg-indigo-500/10 border border-indigo-500/20 px-3 py-1 rounded-xl">
                  {activeMatch ? activeMatch.channelName : (activeChannel ? activeChannel.name : 'Unknown Feed')}
                </span>
                
                {currentStreamUrl && (
                  <div className="flex items-center gap-2 max-w-full">
                    <span className={`font-mono text-[10px] truncate max-w-[200px] sm:max-w-[320px] px-2 py-1 rounded ${
                      theme === 'dark' ? 'bg-slate-950 text-slate-400 border border-slate-800' : 'bg-slate-100 text-slate-600 border border-slate-200'
                    }`}>
                      {window.location.origin + currentStreamUrl}
                    </span>
                    <button 
                      onClick={copyToClipboard}
                      className={`p-1 rounded border transition cursor-pointer ${
                        theme === 'dark'
                          ? 'bg-slate-900 hover:bg-slate-800 border-slate-800 text-slate-400 hover:text-white'
                          : 'bg-white hover:bg-slate-100 border-slate-300 text-slate-600 hover:text-slate-900'
                      }`}
                      title="Copy URL"
                    >
                      {copiedUrl ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Matches & Leagues Section (SofaScore Schedule) */}
          <div className={`rounded-2xl p-5 border ${
            theme === 'dark' ? 'bg-[#0a0e1f] border-slate-850' : 'bg-white border-slate-200 shadow-sm'
          }`}>
            <div className={`flex items-center justify-between border-b pb-4 mb-4 ${theme === 'dark' ? 'border-slate-800' : 'border-slate-200'}`}>
              <div className="flex items-center gap-2">
                <Flame className="w-5 h-5 text-amber-500" />
                <h3 className={`text-sm font-black ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                  جدول مباريات اليوم من SofaScore ومطابقتها للقنوات
                </h3>
              </div>
              <span className={`text-[10px] px-2 py-1 rounded-md border font-mono ${
                theme === 'dark' ? 'text-slate-400 bg-slate-900 border-slate-800/80' : 'text-slate-600 bg-slate-100 border-slate-200'
              }`}>
                Real-Time mapping
              </span>
            </div>

            {isLoadingMatches ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[...Array(4)].map((_, idx) => (
                  <div key={idx} className="p-4 rounded-xl border border-slate-850 bg-slate-900/10 animate-pulse flex flex-col justify-between h-[150px]">
                    <div className="flex items-center justify-between">
                      <div className="h-3.5 w-24 bg-slate-800 rounded"></div>
                      <div className="h-5 w-16 bg-slate-800 rounded-full"></div>
                    </div>
                    <div className="flex items-center justify-between my-2">
                      <div className="flex items-center gap-2.5 w-[42%]">
                        <div className="w-8 h-8 rounded-full bg-slate-800 shrink-0"></div>
                        <div className="h-3 w-16 bg-slate-800 rounded"></div>
                      </div>
                      <div className="w-12 h-6 bg-slate-800 rounded-xl"></div>
                      <div className="flex items-center gap-2.5 w-[42%] justify-end">
                        <div className="h-3 w-16 bg-slate-800 rounded"></div>
                        <div className="w-8 h-8 rounded-full bg-slate-800 shrink-0"></div>
                      </div>
                    </div>
                    <div className="border-t border-slate-800/60 pt-2 flex items-center justify-between">
                      <div className="h-3 w-14 bg-slate-800/80 rounded"></div>
                      <div className="h-3 w-28 bg-slate-800/80 rounded animate-pulse"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : matchesError ? (
              <div className="py-10 text-center flex flex-col items-center justify-center p-6 bg-slate-950/20 border border-slate-850/50 rounded-xl text-slate-300 gap-3">
                <AlertTriangle className="w-8 h-8 text-rose-500 animate-pulse" />
                <p className="text-xs font-bold text-slate-200">{matchesError}</p>
                <button 
                  onClick={fetchMatches}
                  className="mt-2 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 text-[11px] text-white border border-slate-800 transition cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  إعادة محاولة تحديث المباريات
                </button>
              </div>
            ) : !matches || matches.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                لا توجد مباريات جارية حالياً مطابقة لشروط الفرز.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {(matches || []).map((match) => (
                  <div 
                    key={match.id}
                    onClick={() => handleMatchClick(match)}
                    className={`p-4 rounded-xl transition cursor-pointer border relative flex flex-col justify-between h-[150px] ${
                      activeMatch?.id === match.id 
                        ? 'bg-purple-950/20 border-purple-500/50 shadow-lg shadow-purple-500/5' 
                        : theme === 'dark'
                          ? 'bg-slate-900/30 hover:bg-slate-900/60 border-slate-850 hover:border-slate-800'
                          : 'bg-slate-50 hover:bg-white border-slate-200 hover:border-purple-300 shadow-xs'
                    }`}
                  >
                    {/* Header: League & Active Live Badge */}
                    <div className="flex items-center justify-between">
                      <span className={`text-[11px] font-semibold truncate max-w-[70%] ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>
                        {match.league}
                      </span>
                      {match.status === 'LIVE' ? (
                        <span className="flex items-center gap-1 text-[10px] font-black text-red-500 bg-red-500/10 px-2 py-0.5 rounded-full border border-red-500/20">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                          {formatDisplayTime(match.time)}
                        </span>
                      ) : match.status === 'FINISHED' ? (
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${theme === 'dark' ? 'text-slate-500 bg-slate-950' : 'text-slate-500 bg-slate-200'}`}>
                          انتهت
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-[10px] font-semibold text-indigo-500 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                          <Clock className="w-3 h-3" />
                          {formatDisplayTime(match.time)}
                        </span>
                      )}
                    </div>

                    {/* Content: Teams and scores */}
                    <div className="flex items-center justify-between my-2">
                      {/* Home team */}
                      <div className="flex items-center gap-2.5 w-[42%]">
                        <div className="relative shrink-0">
                          {match.homeLogo ? (
                            <img 
                              src={match.homeLogo} 
                              alt={match.homeTeam}
                              referrerPolicy="no-referrer"
                              className={`w-8 h-8 rounded-full object-contain p-1 border ${
                                theme === 'dark' ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-300'
                              }`}
                              onError={(e) => {
                                // Fallback if logo fails
                                e.currentTarget.style.display = 'none';
                                const fb = e.currentTarget.nextElementSibling as HTMLElement;
                                if (fb) fb.style.display = 'flex';
                              }}
                            />
                          ) : null}
                          <div 
                            style={{ display: match.homeLogo ? 'none' : 'flex' }}
                            className={`w-8 h-8 rounded-full bg-gradient-to-tr ${getInitialsColor(match.homeTeam)} text-white font-black text-[10px] flex items-center justify-center border border-slate-800`}
                          >
                            {getInitials(match.homeTeam)}
                          </div>
                        </div>
                        <span className={`text-xs font-bold truncate text-right ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                          {match.homeTeam}
                        </span>
                      </div>

                      {/* Scoreboard */}
                      <div className={`flex items-center justify-center px-3 py-1.5 rounded-xl border gap-2 font-mono ${
                        theme === 'dark' ? 'bg-slate-950/80 border-slate-850' : 'bg-slate-100 border-slate-300'
                      }`}>
                        <span className={`text-sm font-black ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                          {match.homeScore !== null ? match.homeScore : '-'}
                        </span>
                        <span className="text-xs text-slate-400 font-sans">:</span>
                        <span className={`text-sm font-black ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                          {match.awayScore !== null ? match.awayScore : '-'}
                        </span>
                      </div>

                      {/* Away team */}
                      <div className="flex items-center gap-2.5 w-[42%] justify-end text-left">
                        <span className={`text-xs font-bold truncate ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                          {match.awayTeam}
                        </span>
                        <div className="relative shrink-0">
                          {match.awayLogo ? (
                            <img 
                              src={match.awayLogo} 
                              alt={match.awayTeam}
                              referrerPolicy="no-referrer"
                              className={`w-8 h-8 rounded-full object-contain p-1 border ${
                                theme === 'dark' ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-300'
                              }`}
                              onError={(e) => {
                                e.currentTarget.style.display = 'none';
                                const fb = e.currentTarget.nextElementSibling as HTMLElement;
                                if (fb) fb.style.display = 'flex';
                              }}
                            />
                          ) : null}
                          <div 
                            style={{ display: match.awayLogo ? 'none' : 'flex' }}
                            className={`w-8 h-8 rounded-full bg-gradient-to-tr ${getInitialsColor(match.awayTeam)} text-white font-black text-[10px] flex items-center justify-center border border-slate-800`}
                          >
                            {getInitials(match.awayTeam)}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Footer: Channel Mapping Info */}
                    <div className="border-t border-slate-800/60 pt-2 flex items-center justify-between">
                      <span className="text-[10px] font-bold text-slate-500">
                        القناة الناقلة:
                      </span>
                      <span className="text-[10px] font-black text-purple-400 truncate max-w-[80%] flex items-center gap-1">
                        <Tv className="w-3 h-3 text-purple-400" />
                        {match.channelName}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: IPTV Channel Selection & Filters */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          <div className={`glass-panel rounded-3xl p-5 border flex flex-col h-[650px] ${
            theme === 'dark' ? 'border-slate-800/80' : 'border-slate-200 shadow-sm'
          }`}>
            
            {/* Search and Header */}
            <div className="space-y-4 mb-4">
              <div className="flex items-center justify-between">
                <h3 className={`text-sm font-black flex items-center gap-2 ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                  <Tv className="w-4 h-4 text-purple-500" />
                  قائمة القنوات الرياضية المتاحة
                </h3>
                <span className="text-[10px] font-semibold bg-purple-500/10 text-purple-500 border border-purple-500/20 px-2 py-0.5 rounded">
                  {filteredChannels.length} قناة
                </span>
              </div>

              {/* Search input */}
              <div className="relative">
                <input 
                  type="text"
                  placeholder="ابحث عن قناة (مثال: beIN, SSC)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={`w-full border focus:border-purple-500 rounded-xl px-4 py-2.5 pl-10 text-xs focus:outline-none transition ${
                    theme === 'dark' 
                      ? 'bg-slate-950 border-slate-800 text-slate-200 placeholder-slate-500' 
                      : 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400'
                  }`}
                />
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              </div>

              {/* Category Quick Filters */}
              <div className="flex flex-wrap items-center justify-between gap-1.5">
                <div className="flex flex-wrap gap-1.5">
                  {['All', 'beIN', 'SSC', 'Arryadia', 'Canal+'].map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                        selectedCategory === cat 
                          ? 'bg-purple-600 text-white' 
                          : theme === 'dark'
                            ? 'bg-slate-900 hover:bg-slate-800 text-slate-400 border border-slate-850'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                      }`}
                    >
                      {cat === 'All' ? 'الكل' : cat}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => setOnlyShowSd(!onlyShowSd)}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-black transition flex items-center gap-1 cursor-pointer border ${
                    onlyShowSd 
                      ? 'bg-amber-600 text-white border-amber-500 shadow-md shadow-amber-500/10' 
                      : 'bg-amber-500/10 text-amber-500 hover:bg-amber-500/20 border-amber-500/20'
                  }`}
                  title="عرض القنوات التي توفر جودة منخفضة خفيفة فقط"
                >
                  <Zap className="w-3 h-3" />
                  SD خفيف
                </button>
              </div>

              {/* M3U Upload Bypass */}
              <div className={`p-3 rounded-xl border flex flex-col gap-2 ${
                theme === 'dark' ? 'bg-[#0b0f24] border-slate-850' : 'bg-slate-50 border-slate-200'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black text-purple-500 uppercase tracking-wider flex items-center gap-1">
                    <ExternalLink className="w-3 h-3" />
                    تحميل ملف M3U خارجي (Bypass)
                  </span>
                  {isM3uLoaded && (
                    <span className="text-[9px] text-emerald-500 font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded">
                      قائمتك نشطة
                    </span>
                  )}
                </div>
                <label className={`flex items-center justify-center gap-2 px-3 py-2 border border-dashed rounded-lg cursor-pointer transition group text-[11px] ${
                  theme === 'dark'
                    ? 'border-slate-800 hover:border-purple-500/50 bg-slate-900/40 hover:bg-slate-900/80 text-slate-400 hover:text-white'
                    : 'border-slate-300 hover:border-purple-500/50 bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-900'
                }`}>
                  <Copy className="w-3.5 h-3.5 text-slate-400 group-hover:text-purple-500" />
                  <span className="truncate max-w-[180px]">
                    {isM3uLoaded ? m3uFileName : "اختر ملف IPTV m3u لتشغيله مباشرة"}
                  </span>
                  <input 
                    type="file" 
                    accept=".m3u" 
                    onChange={handleM3uUpload} 
                    className="hidden" 
                  />
                </label>
              </div>

              {/* Paste Custom HLS URL Stream */}
              <div className={`p-3 rounded-xl border flex flex-col gap-2 ${
                theme === 'dark' ? 'bg-[#0b0f24] border-slate-850' : 'bg-slate-50 border-slate-200'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black text-indigo-400 uppercase tracking-wider flex items-center gap-1">
                    <Link2 className="w-3.5 h-3.5 text-indigo-400" />
                    تشغيل رابط HLS / .m3u8 مباشر
                  </span>
                  <span className="text-[9px] text-slate-500 font-mono">Proxy Auto</span>
                </div>
                <form onSubmit={handlePlayCustomUrl} className="flex gap-1.5">
                  <input
                    type="url"
                    placeholder="ضع رابط .m3u8 المنسوخ من موقع آخر هنا..."
                    value={customUrl}
                    onChange={(e) => setCustomUrl(e.target.value)}
                    className={`flex-1 border focus:border-indigo-500 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none transition ${
                      theme === 'dark'
                        ? 'bg-slate-950 border-slate-800 text-slate-200 placeholder-slate-600'
                        : 'bg-white border-slate-300 text-slate-900 placeholder-slate-400'
                    }`}
                  />
                  <button
                    type="submit"
                    disabled={!customUrl.trim()}
                    className="px-3 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-lg text-xs font-bold transition disabled:opacity-40 disabled:cursor-not-allowed shrink-0 flex items-center gap-1 cursor-pointer shadow-xs"
                  >
                    <Play className="w-3 h-3 fill-white" />
                    تشغيل
                  </button>
                </form>
              </div>
            </div>

            {/* Channels Grid/List Scrollable Area */}
            <div className="flex-grow overflow-y-auto pr-1 space-y-2">
              {isLoadingChannels ? (
                <div className="space-y-2.5">
                  {[...Array(6)].map((_, idx) => (
                    <div key={idx} className="p-3 rounded-xl border border-slate-850 bg-slate-900/10 animate-pulse flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-slate-800 shrink-0"></div>
                        <div className="space-y-1.5">
                          <div className="h-3 w-28 bg-slate-800 rounded"></div>
                          <div className="h-2 w-16 bg-slate-800 rounded"></div>
                        </div>
                      </div>
                      <div className="w-7 h-7 rounded-lg bg-slate-800 shrink-0"></div>
                    </div>
                  ))}
                </div>
              ) : channelsError ? (
                <div className="py-8 text-center flex flex-col items-center justify-center p-5 bg-slate-950/20 border border-slate-850/40 rounded-xl text-slate-400 gap-3">
                  <AlertTriangle className="w-7 h-7 text-rose-500/80 animate-pulse" />
                  <p className="text-xs font-bold text-slate-300">{channelsError}</p>
                  <button 
                    onClick={fetchChannels}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 text-[10px] text-white border border-slate-800 transition cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    إعادة محاولة الاتصال بالخادم
                  </button>
                </div>
              ) : !filteredChannels || filteredChannels.length === 0 ? (
                <div className="h-full flex items-center justify-center text-slate-500 text-xs py-12">
                  لم يتم العثور على قنوات تطابق البحث.
                </div>
              ) : (
                (filteredChannels || []).map((channel) => {
                  const hasSd = channel.qualities && channel.qualities.some(q => q.quality.toUpperCase() === 'SD');
                  const sdQualityObj = channel.qualities?.find(q => q.quality.toUpperCase() === 'SD');
                  const isCurrentlyPlayingSd = activeChannel?.id === channel.id && sdQualityObj && currentStreamUrl === sdQualityObj.streamUrl;

                  return (
                    <div
                      key={channel.id}
                      onClick={() => handleChannelClick(channel)}
                      className={`p-3 rounded-xl transition cursor-pointer flex items-center justify-between border ${
                        activeChannel?.id === channel.id
                          ? 'bg-purple-950/25 border-purple-500/50 shadow-md shadow-purple-500/5'
                          : theme === 'dark'
                            ? 'bg-slate-900/20 hover:bg-slate-900/55 border-slate-850 hover:border-slate-800'
                            : 'bg-slate-50 hover:bg-white border-slate-200 hover:border-purple-300 shadow-xs'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className={`w-10 h-10 rounded-lg border p-1 flex items-center justify-center shrink-0 ${
                          theme === 'dark' ? 'bg-slate-950 border-slate-850' : 'bg-slate-100 border-slate-200'
                        }`}>
                          {channel.logo ? (
                            <img 
                              src={channel.logo} 
                              alt={channel.name} 
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-contain"
                              onError={(e) => {
                                e.currentTarget.style.display = 'none';
                                const icon = e.currentTarget.nextElementSibling as HTMLElement;
                                if (icon) icon.style.display = 'block';
                              }}
                            />
                          ) : null}
                          <Tv 
                            style={{ display: channel.logo ? 'none' : 'block' }}
                            className="w-5 h-5 text-purple-400" 
                          />
                        </div>
                        <div className="min-w-0">
                          <span className={`text-xs font-bold block truncate ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                            {channel.name}
                          </span>
                          <span className={`text-[9px] font-mono block mt-0.5 ${theme === 'dark' ? 'text-slate-500' : 'text-slate-400'}`}>
                            ID: {channel.id}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {hasSd && sdQualityObj && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveMatch(null);
                              setActiveChannel(channel);
                              handlePlayStream(sdQualityObj.streamUrl, channel.name);
                            }}
                            className={`px-2 py-0.5 rounded text-[8px] font-black border transition cursor-pointer ${
                              isCurrentlyPlayingSd
                                ? 'bg-amber-600 text-white border-amber-500 shadow shadow-amber-500/25'
                                : 'bg-amber-500/10 text-amber-500 hover:bg-amber-500 hover:text-white border-amber-500/20'
                            }`}
                            title="تشغيل جودة SD المنخفضة مباشرة"
                          >
                            SD خفيف
                          </button>
                        )}

                        {activeChannel?.id === channel.id ? (
                          <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
                        ) : (
                          <div className={`w-7 h-7 rounded-lg flex items-center justify-center border transition ${
                            theme === 'dark'
                              ? 'bg-slate-950 text-slate-400 border-slate-850 group-hover:bg-purple-600'
                              : 'bg-white text-slate-500 border-slate-200 group-hover:bg-purple-600'
                          }`}>
                            <Play className="w-3.5 h-3.5 fill-current" />
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
            
            {/* Quick Status Bar */}
            <div className={`border-t pt-3 mt-3 flex items-center justify-between text-[10px] font-mono ${
              theme === 'dark' ? 'border-slate-800 text-slate-400' : 'border-slate-200 text-slate-500'
            }`}>
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                IPTV Protocol: Xtream
              </span>
              <span>Proxy Port: 3000</span>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className={`border-t py-6 text-center text-xs space-y-1.5 transition-colors ${
        theme === 'dark' ? 'border-slate-900 bg-[#04060c] text-slate-500' : 'border-slate-200 bg-white text-slate-600'
      }`}>
        <p>© {new Date().getFullYear()} ماجد لايف - لوحة فك التشفير التلقائية الذكية • جميع الحقوق محفوظة.</p>
        <p className={`font-mono text-[10px] ${theme === 'dark' ? 'text-slate-600' : 'text-slate-400'}`}>
          SofaScore automated event schedule + Xtream Player API proxy engine
        </p>
      </footer>
    </div>
  );
}
