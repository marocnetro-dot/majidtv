/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Tv, 
  Activity, 
  RefreshCw, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  AlertTriangle, 
  Flame, 
  Clock, 
  Sliders, 
  Copy, 
  Check, 
  ShieldCheck, 
  Zap, 
  Link2, 
  Sun, 
  Moon,
  Plus,
  Trash2,
  Edit3,
  Save,
  Settings,
  ArrowRight,
  Lock,
  Search,
  Calendar,
  LogOut,
  X,
  Radio,
  ChevronLeft,
  ChevronRight,
  Globe,
  Share2,
  Eye,
  EyeOff,
  ArrowUp,
  ArrowDown,
  Mail,
  Trophy
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Hls from 'hls.js';

interface Match {
  id: string;
  homeTeam: string;
  awayTeam: string;
  homeLogo: string;
  awayLogo: string;
  homeScore: number | null;
  awayScore: number | null;
  league: string;
  status: 'LIVE' | 'UPCOMING' | 'FINISHED';
  time: string;
  dateCategory?: 'today' | 'tomorrow';
  channelName?: string;
  streamUrl?: string | null;
  qualities?: { quality: string; streamId: number | string; streamUrl: string; name?: string; }[];
  hidden?: boolean;
  order?: number;
}

const MAJOR_LEAGUES = [
  {
    id: 'all',
    name: 'جميع الدوريات',
    nameEn: 'All Leagues',
    logo: '🏆',
    isEmoji: true,
    keywords: []
  },
  {
    id: 'epl',
    name: 'الدوري الإنجليزي',
    nameEn: 'Premier League',
    logo: 'https://a.espncdn.com/i/leaguelogos/soccer/500/23.png',
    keywords: ['premier league', 'إنجليزي', 'انجلترا', 'epl', 'premier']
  },
  {
    id: 'laliga',
    name: 'الدوري الإسباني',
    nameEn: 'La Liga',
    logo: 'https://a.espncdn.com/i/leaguelogos/soccer/500/15.png',
    keywords: ['la liga', 'laliga', 'إسباني', 'اسبانيا']
  },
  {
    id: 'seriea',
    name: 'الدوري الإيطالي',
    nameEn: 'Serie A',
    logo: 'https://a.espncdn.com/i/leaguelogos/soccer/500/12.png',
    keywords: ['serie a', 'إيطالي', 'ايطاليا', 'serie']
  },
  {
    id: 'ligue1',
    name: 'الدوري الفرنسي',
    nameEn: 'Ligue 1',
    logo: 'https://a.espncdn.com/i/leaguelogos/soccer/500/9.png',
    keywords: ['ligue 1', 'فرنسي', 'فرنسا', 'ligue']
  },
  {
    id: 'champions',
    name: 'دوري أبطال أوروبا',
    nameEn: 'Champions League',
    logo: 'https://a.espncdn.com/i/leaguelogos/soccer/500/2.png',
    keywords: ['champions league', 'أبطال أوروبا', 'ابطال اوروبا', 'champions', 'ucl']
  }
];

export default function App() {
  // Navigation / Route state
  const [currentRoute, setCurrentRoute] = useState<'public' | 'match' | 'admin'>(() => {
    if (window.location.pathname.startsWith('/admin')) return 'admin';
    if (window.location.pathname.startsWith('/match')) return 'match';
    return 'public';
  });

  // Admin Auth state
  const [adminToken, setAdminToken] = useState<string | null>(() => {
    return localStorage.getItem('majid_admin_token');
  });
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [emailCopied, setEmailCopied] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText('majidtv@outlook.fr');
    setEmailCopied(true);
    setTimeout(() => setEmailCopied(false), 2500);
  };

  const navigateTo = (route: 'public' | 'match' | 'admin', match?: Match) => {
    setCurrentRoute(route);
    if (route === 'admin') {
      window.history.pushState({}, '', '/admin');
    } else if (route === 'match' && (match || activeMatch)) {
      const targetMatch = match || activeMatch;
      if (targetMatch) {
        window.history.pushState({}, '', `/match/${targetMatch.id}`);
      }
    } else {
      window.history.pushState({}, '', '/');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    const handleLocationChange = () => {
      if (window.location.pathname.startsWith('/admin')) {
        setCurrentRoute('admin');
      } else if (window.location.pathname.startsWith('/match')) {
        setCurrentRoute('match');
      } else {
        setCurrentRoute('public');
      }
    };
    window.addEventListener('popstate', handleLocationChange);
    return () => window.removeEventListener('popstate', handleLocationChange);
  }, []);

  // Admin Login Handler
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    setLoginError(null);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: loginUsername.trim(), password: loginPassword.trim() })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setAdminToken(data.token);
        localStorage.setItem('majid_admin_token', data.token);
        setLoginUsername('');
        setLoginPassword('');
      } else {
        setLoginError(data.message || 'اسم المستخدم أو كلمة المرور غير صحيحة');
      }
    } catch (err: any) {
      setLoginError('تعذر الاتصال بخادم المصادقة');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleAdminLogout = () => {
    setAdminToken(null);
    localStorage.removeItem('majid_admin_token');
  };

  // Format display time
  const formatDisplayTime = (timeVal: any): string => {
    if (timeVal === null || timeVal === undefined) return 'اليوم';
    if (typeof timeVal === 'string') {
      return timeVal.trim();
    }
    if (typeof timeVal === 'number') return `${timeVal}'`;
    if (typeof timeVal === 'object') {
      if (timeVal.minute !== undefined) {
        return `${timeVal.minute}${timeVal.extra ? '+' + timeVal.extra : ''}'`;
      }
      if (timeVal.time !== undefined && typeof timeVal.time !== 'object') {
        return String(timeVal.time);
      }
      if (timeVal.type) return String(timeVal.type);
      try {
        return JSON.stringify(timeVal);
      } catch (e) {
        return 'مباشر';
      }
    }
    return String(timeVal);
  };

  // Public State
  const [matches, setMatches] = useState<Match[]>([]);
  const [activeMatch, setActiveMatch] = useState<Match | null>(null);
  const [currentStreamUrl, setCurrentStreamUrl] = useState<string>('');
  const [activeQuality, setActiveQuality] = useState<string>('FHD');
  const [isLoadingMatches, setIsLoadingMatches] = useState(true);
  const [matchesError, setMatchesError] = useState<string | null>(null);
  const [isLoadingStream, setIsLoadingStream] = useState(false);
  const [streamError, setStreamError] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Active Date Filter Tab: 'today' | 'live' | 'tomorrow'
  const [activeDayTab, setActiveDayTab] = useState<'today' | 'live' | 'tomorrow'>('today');
  // Selected Major League filter: 'all' | 'epl' | 'laliga' | 'seriea' | 'ligue1' | 'champions'
  const [selectedLeague, setSelectedLeague] = useState<string>('all');

  // Video element refs
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);

  // Admin form & management state
  const [adminMatches, setAdminMatches] = useState<Match[]>([]);
  const [editingMatchId, setEditingMatchId] = useState<string | null>(null);
  const [formHomeTeam, setFormHomeTeam] = useState('');
  const [formAwayTeam, setFormAwayTeam] = useState('');
  const [formHomeLogo, setFormHomeLogo] = useState('');
  const [formAwayLogo, setFormAwayLogo] = useState('');
  const [formLeague, setFormLeague] = useState('الدوري الإسباني (La Liga)');
  const [formStatus, setFormStatus] = useState<'LIVE' | 'UPCOMING' | 'FINISHED'>('LIVE');
  const [formTime, setFormTime] = useState('20:00');
  const [formDateCategory, setFormDateCategory] = useState<'today' | 'tomorrow'>('today');
  const [formHomeScore, setFormHomeScore] = useState<string>('');
  const [formAwayScore, setFormAwayScore] = useState<string>('');
  const [formStreamUrl, setFormStreamUrl] = useState('');
  const [formChannelName, setFormChannelName] = useState('beIN Sports HD1');
  const [isSavingAdmin, setIsSavingAdmin] = useState(false);
  const [adminMsg, setAdminMsg] = useState<{ text: string; type: 'success' | 'error' | null }>({ text: '', type: null });

  // Initial load & periodic auto-refresh for live scores
  useEffect(() => {
    fetchMatches();
    fetchAdminMatches();

    const interval = setInterval(() => {
      fetchMatches(false, true); // silent live score update
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const fetchMatches = async (force: boolean = false, isSilent: boolean = false) => {
    if (!isSilent) setIsLoadingMatches(true);
    setMatchesError(null);
    try {
      const res = await fetch(`/api/live-matches${force ? '?force=true' : ''}`);
      if (res.ok) {
        const data = await res.json();
        const safeData = Array.isArray(data) ? data : [];
        setMatches(safeData);
      } else if (!isSilent) {
        setMatchesError('حدث خطأ أثناء جلب المباريات.');
      }
    } catch (err) {
      console.error("Failed to load matches:", err);
      if (!isSilent) setMatchesError('تعذر الاتصال بالخادم لجلب جدول المباريات.');
    } finally {
      if (!isSilent) setIsLoadingMatches(false);
    }
  };

  const fetchAdminMatches = async () => {
    try {
      const res = await fetch('/api/admin/matches');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          setAdminMatches(data);
        }
      }
    } catch (err) {
      console.error("Failed to fetch admin matches:", err);
    }
  };

  const handleQuickStreamUrlChange = (matchId: string, newUrl: string) => {
    setAdminMatches(prev => prev.map(m => m.id === matchId ? { ...m, streamUrl: newUrl } : m));
    setMatches(prev => prev.map(m => m.id === matchId ? { ...m, streamUrl: newUrl } : m));
    if (editingMatchId === matchId) {
      setFormStreamUrl(newUrl);
    }
  };

  // Select match and navigate to stream page
  const handleSelectMatch = (match: Match) => {
    setActiveMatch(match);
    const stream = match.streamUrl || `/api/proxy?url=${encodeURIComponent('https://test-streams.mux.dev/x36xhg/x36xhg.m3u8')}`;
    setCurrentStreamUrl(stream);
    setActiveQuality('FHD');
    setIsLoadingStream(true);
    setStreamError(null);
    setIsPlaying(false);
    navigateTo('match', match);
  };

  // Video player logic
  useEffect(() => {
    if (currentRoute !== 'match' || !currentStreamUrl) return;

    const timer = setTimeout(() => {
      const video = videoRef.current;
      if (!video) return;

      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }

      const fullProxyUrl = currentStreamUrl.startsWith('http') ? currentStreamUrl : window.location.origin + currentStreamUrl;

      if (Hls.isSupported()) {
        const hls = new Hls({
          maxMaxBufferLength: 10,
          lowLatencyMode: true,
          enableWorker: true,
          backBufferLength: 30,
          xhrSetup: (xhr) => {
            xhr.withCredentials = false;
          }
        });
        hlsRef.current = hls;

        hls.loadSource(fullProxyUrl);
        hls.attachMedia(video);

        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          setIsLoadingStream(false);
          setIsPlaying(true);
          video.play().catch(e => console.log("Autoplay blocked", e));
        });

        hls.on(Hls.Events.ERROR, (event, data) => {
          if (data.fatal) {
            switch (data.type) {
              case Hls.ErrorTypes.NETWORK_ERROR:
                console.warn("HLS network error, attempting recovery...", data);
                hls.startLoad();
                break;
              case Hls.ErrorTypes.MEDIA_ERROR:
                console.warn("HLS media error, recovering...", data);
                hls.recoverMediaError();
                break;
              default:
                setIsLoadingStream(false);
                setStreamError("تعذر تشغيل هذا البث. يرجى التحقق من صحة رابط HLS.");
                hls.destroy();
                hlsRef.current = null;
                break;
            }
          }
        });
      } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
        video.src = fullProxyUrl;
        video.addEventListener('loadedmetadata', () => {
          setIsLoadingStream(false);
          setIsPlaying(true);
          video.play().catch(e => console.log("Autoplay blocked", e));
        });
      } else {
        setIsLoadingStream(false);
        setStreamError("متصفحك لا يدعم تشغيل روابط HLS (.m3u8).");
      }
    }, 100);

    return () => {
      clearTimeout(timer);
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [currentStreamUrl, currentRoute]);

  // Video Controls handlers
  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    if (isMuted) {
      videoRef.current.volume = volume || 0.8;
      setIsMuted(false);
    } else {
      videoRef.current.volume = 0;
      setIsMuted(true);
    }
  };

  const toggleFullscreen = () => {
    if (!videoRef.current) return;
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      videoRef.current.requestFullscreen();
    }
  };



  // Team Initials
  const getInitials = (name: string) => {
    if (!name) return 'FC';
    const words = name.trim().split(' ');
    if (words.length === 1) return words[0].substring(0, 2).toUpperCase();
    return (words[0][0] + words[1][0]).toUpperCase();
  };

  const getInitialsColor = (name: string) => {
    const colors = [
      'from-blue-600 to-indigo-700',
      'from-emerald-600 to-teal-700',
      'from-rose-600 to-red-700',
      'from-amber-600 to-orange-700',
      'from-purple-600 to-violet-700'
    ];
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    return colors[Math.abs(hash) % colors.length];
  };

  const getLeagueLogo = (leagueName: string) => {
    if (!leagueName) return null;
    const l = leagueName.toLowerCase();
    for (const lg of MAJOR_LEAGUES) {
      if (lg.keywords.some(k => l.includes(k))) {
        return lg.logo;
      }
    }
    return null;
  };

  // Filter matches based on active tab, selected league & search query
  const getFilteredMatches = () => {
    let list = (matches || []).filter(m => !m.hidden);

    // Selected League Filter
    if (selectedLeague !== 'all') {
      const activeLg = MAJOR_LEAGUES.find(l => l.id === selectedLeague);
      if (activeLg && activeLg.keywords.length > 0) {
        list = list.filter(m => {
          const lName = (m.league || '').toLowerCase();
          return activeLg.keywords.some(k => lName.includes(k));
        });
      }
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(m => 
        m.homeTeam.toLowerCase().includes(q) || 
        m.awayTeam.toLowerCase().includes(q) || 
        m.league.toLowerCase().includes(q)
      );
    }

    // Tab filter
    if (activeDayTab === 'live') {
      return list.filter(m => m.status === 'LIVE');
    } else if (activeDayTab === 'today') {
      return list.filter(m => !m.dateCategory || m.dateCategory === 'today');
    } else if (activeDayTab === 'tomorrow') {
      return list.filter(m => m.dateCategory === 'tomorrow');
    }

    return list;
  };

  // Dynamic Top Matches Widget (أبرز المباريات)
  const getTop11Matches = () => {
    let list = (matches || []).filter(m => !m.hidden);

    if (selectedLeague !== 'all') {
      const activeLg = MAJOR_LEAGUES.find(l => l.id === selectedLeague);
      if (activeLg && activeLg.keywords.length > 0) {
        list = list.filter(m => {
          const lName = (m.league || '').toLowerCase();
          return activeLg.keywords.some(k => lName.includes(k));
        });
      }
    }

    // Prioritize LIVE, then UPCOMING, then FINISHED
    const liveMatches = list.filter(m => m.status === 'LIVE');
    const upcomingMatches = list.filter(m => m.status === 'UPCOMING');
    const finishedMatches = list.filter(m => m.status === 'FINISHED');

    const ordered = [...liveMatches, ...upcomingMatches, ...finishedMatches];
    return ordered.slice(0, 5);
  };

  // ADMIN HANDLERS
  const handleToggleHideMatch = (id: string) => {
    setAdminMatches(prev => prev.map(m => m.id === id ? { ...m, hidden: !m.hidden } : m));
    setMatches(prev => prev.map(m => m.id === id ? { ...m, hidden: !m.hidden } : m));
  };

  const handleMoveMatchUp = (index: number) => {
    if (index <= 0) return;
    setAdminMatches(prev => {
      const next = [...prev];
      const temp = next[index];
      next[index] = next[index - 1];
      next[index - 1] = temp;
      return next;
    });
  };

  const handleMoveMatchDown = (index: number) => {
    setAdminMatches(prev => {
      if (index >= prev.length - 1) return prev;
      const next = [...prev];
      const temp = next[index];
      next[index] = next[index + 1];
      next[index + 1] = temp;
      return next;
    });
  };

  const handleSaveMatchForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formHomeTeam.trim() || !formAwayTeam.trim()) {
      setAdminMsg({ text: 'يرجى إدخال اسم الفريق المستضيف والفريق الضيف', type: 'error' });
      return;
    }

    let finalStreamUrl = formStreamUrl.trim();
    if (finalStreamUrl && !finalStreamUrl.startsWith('/api/proxy') && (finalStreamUrl.startsWith('http://') || finalStreamUrl.startsWith('https://'))) {
      finalStreamUrl = `/api/proxy?url=${encodeURIComponent(finalStreamUrl)}`;
    }

    const existingMatch = editingMatchId ? adminMatches.find(m => m.id === editingMatchId) : null;

    const matchObj: Match = {
      id: editingMatchId || `match_${Date.now()}`,
      homeTeam: formHomeTeam.trim(),
      awayTeam: formAwayTeam.trim(),
      homeLogo: formHomeLogo.trim(),
      awayLogo: formAwayLogo.trim(),
      league: formLeague.trim(),
      status: formStatus,
      time: formTime.trim() || (formStatus === 'LIVE' ? "45'" : "20:00"),
      dateCategory: formDateCategory,
      homeScore: formHomeScore !== '' ? parseInt(formHomeScore) : null,
      awayScore: formAwayScore !== '' ? parseInt(formAwayScore) : null,
      streamUrl: finalStreamUrl || `/api/proxy?url=${encodeURIComponent('https://test-streams.mux.dev/x36xhg/x36xhg.m3u8')}`,
      channelName: formChannelName.trim() || 'beIN Sports HD1',
      hidden: existingMatch ? existingMatch.hidden : false
    };

    if (editingMatchId) {
      setAdminMatches(prev => prev.map(m => m.id === editingMatchId ? matchObj : m));
      setAdminMsg({ text: 'تم تحديث المباراة في القائمة الحالية (اضغط حفظ ونشر للارسال)', type: 'success' });
    } else {
      setAdminMatches(prev => [matchObj, ...prev]);
      setAdminMsg({ text: 'تمت إضافة المباراة بالقائمة الحالية (اضغط حفظ ونشر للارسال)', type: 'success' });
    }

    resetForm();
  };

  const resetForm = () => {
    setEditingMatchId(null);
    setFormHomeTeam('');
    setFormAwayTeam('');
    setFormHomeLogo('');
    setFormAwayLogo('');
    setFormLeague('الدوري الإسباني (La Liga)');
    setFormStatus('LIVE');
    setFormTime("20:00");
    setFormDateCategory('today');
    setFormHomeScore('');
    setFormAwayScore('');
    setFormStreamUrl('');
    setFormChannelName('beIN Sports HD1');
  };

  const handleEditMatchClick = (match: Match) => {
    setEditingMatchId(match.id);
    setFormHomeTeam(match.homeTeam);
    setFormAwayTeam(match.awayTeam);
    setFormHomeLogo(match.homeLogo || '');
    setFormAwayLogo(match.awayLogo || '');
    setFormLeague(match.league);
    setFormStatus(match.status);
    setFormTime(match.time || '20:00');
    setFormDateCategory(match.dateCategory || 'today');
    setFormHomeScore(match.homeScore !== null ? String(match.homeScore) : '');
    setFormAwayScore(match.awayScore !== null ? String(match.awayScore) : '');

    let rawUrl = match.streamUrl || '';
    if (rawUrl.includes('/api/proxy?url=')) {
      rawUrl = decodeURIComponent(rawUrl.split('/api/proxy?url=')[1]);
    }
    setFormStreamUrl(rawUrl);
    setFormChannelName(match.channelName || 'beIN Sports HD1');
  };

  const handleDeleteMatchClick = (id: string) => {
    setAdminMatches(prev => prev.filter(m => m.id !== id));
    setAdminMsg({ text: 'تم حذف المباراة من القائمة', type: 'success' });
  };

  const handleSaveAllToBackend = async () => {
    setIsSavingAdmin(true);
    setAdminMsg({ text: 'جاري حفظ الجدول المباشر على الخادم...', type: 'success' });
    try {
      const res = await fetch('/api/admin/matches', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ matches: adminMatches })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setAdminMsg({ text: 'تم حفظ جدول المباريات وروابط البث بنجاح وتطبيقها للمستعملين!', type: 'success' });
        fetchMatches(true);
      } else {
        setAdminMsg({ text: data.message || 'حدث خطأ أثناء حفظ الجدول', type: 'error' });
      }
    } catch (err: any) {
      setAdminMsg({ text: `فشل الاتصال بالخادم: ${err.message}`, type: 'error' });
    } finally {
      setIsSavingAdmin(false);
    }
  };

  const handleResetDefaults = async () => {
    if (!confirm('هل أنت تأكد من إزالة الجدول الخاص وإعادة تعيين جدول المباريات الافتراضي؟')) return;
    setIsSavingAdmin(true);
    try {
      const res = await fetch('/api/admin/matches/reset', { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        setAdminMatches(data.matches || []);
        setAdminMsg({ text: 'تمت إعادة تعيين المباريات للجدول الافتراضي', type: 'success' });
        fetchMatches(true);
      }
    } catch (err: any) {
      setAdminMsg({ text: 'حدث خطأ أثناء إعادة التعيين', type: 'error' });
    } finally {
      setIsSavingAdmin(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0f19] text-slate-100 font-sans flex flex-col selection:bg-sky-600 selection:text-white">
      
      {/* TOP NAVBAR (Sir TV / Majid Live Header) */}
      <header className="sticky top-0 z-40 bg-[#0e1322]/95 border-b border-slate-800 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          
          {/* Logo & Brand */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigateTo('public')}>
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-b from-[#183a6b] to-[#0c1f3c] border border-[#2d5896] flex items-center justify-center shadow-lg shadow-sky-950/40">
              <Play className="w-4 h-4 text-white fill-white ml-0.5" />
            </div>
            <div>
              <h1 className="text-base font-black tracking-tight text-white font-sans flex items-center gap-1.5">
                majid tv <span className="text-cyan-300 font-bold text-xs">مجيد تي في</span>
              </h1>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 text-xs font-bold text-slate-300">
            <button onClick={() => { navigateTo('public'); setActiveDayTab('today'); }} className="hover:text-sky-400 transition cursor-pointer">الرئيسية</button>
            <button onClick={() => { navigateTo('public'); setActiveDayTab('live'); }} className="hover:text-emerald-400 transition cursor-pointer flex items-center gap-1.5 text-emerald-400 font-black">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              مباشر
            </button>
            <button onClick={() => { navigateTo('public'); setActiveDayTab('today'); }} className="hover:text-sky-400 transition cursor-pointer">مباريات اليوم</button>
            <button onClick={() => { navigateTo('public'); setActiveDayTab('tomorrow'); }} className="hover:text-sky-400 transition cursor-pointer">مباريات الغد</button>
            <button onClick={() => { navigateTo('public'); setActiveDayTab('yesterday'); }} className="hover:text-sky-400 transition cursor-pointer">الأمس</button>
          </nav>

          {/* Right Controls / Contact & Admin Toggle */}
          <div className="flex items-center gap-2.5">
            {/* Contact Email Button */}
            <button
              type="button"
              onClick={handleCopyEmail}
              title="انقر لنسخ البريد الإلكتروني للتواصل معي"
              className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-sky-950 to-slate-900 border border-sky-500/30 hover:border-sky-400 text-slate-200 hover:text-white text-xs font-bold transition shadow-sm cursor-pointer group shrink-0"
            >
              <Mail className="w-3.5 h-3.5 text-sky-400 group-hover:scale-110 transition-transform" />
              <span className="hidden sm:inline text-sky-300 font-extrabold text-[11px]">للتواصل معي:</span>
              <span className="font-mono text-[11px] text-sky-200 dir-ltr">majidtv@outlook.fr</span>
              {emailCopied ? (
                <span className="flex items-center gap-1 text-emerald-400 font-bold text-[10px] bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                  <Check className="w-3 h-3 text-emerald-400" />
                  تم النسخ!
                </span>
              ) : (
                <Copy className="w-3 h-3 text-slate-400 group-hover:text-sky-300 ml-0.5" />
              )}
            </button>

            <div className="relative hidden md:block">
              <input
                type="text"
                placeholder="بحث عن مباراة..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-900 border border-slate-800 focus:border-sky-500 rounded-full pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 outline-none w-36 transition focus:w-48"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            </div>

            {currentRoute === 'admin' ? (
              <button 
                onClick={() => navigateTo('public')}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition cursor-pointer border border-slate-700"
              >
                <ArrowRight className="w-3.5 h-3.5" />
                العودة للموقع
              </button>
            ) : currentRoute === 'match' ? (
              <button 
                onClick={() => navigateTo('public')}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-sky-300 text-xs font-bold transition cursor-pointer border border-slate-700 shadow-md"
              >
                <ChevronRight className="w-4 h-4" />
                العودة لجدول المباريات
              </button>
            ) : null}
          </div>
        </div>
      </header>

      {/* RENDER VIEW ACCORDING TO ROUTE */}
      {currentRoute === 'admin' ? (
        /* DEDICATED ADMIN ROUTE (/admin) */
        <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 py-8">
          
          {/* Check Admin Auth */}
          {!adminToken ? (
            /* ADMIN LOGIN FORM REQUIRED */
            <div className="max-w-md mx-auto my-12 bg-[#111726] p-8 rounded-3xl border border-slate-800 shadow-2xl space-y-6 text-center">
              <div className="w-16 h-16 bg-sky-500/10 border border-sky-500/20 rounded-2xl flex items-center justify-center mx-auto text-sky-400">
                <Lock className="w-8 h-8" />
              </div>

              <div>
                <h2 className="text-xl font-black text-white">تسجيل الدخول للوحة التحكم</h2>
                <p className="text-xs text-slate-400 mt-1">الرجاء إدخال اسم المستخدم وكلمة المرور للوصول لإدارة المباريات</p>
              </div>

              {loginError && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-xl text-xs font-bold">
                  {loginError}
                </div>
              )}

              <form onSubmit={handleAdminLogin} className="space-y-4 text-right">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5">اسم المستخدم (Username)</label>
                  <input 
                    type="text"
                    value={loginUsername}
                    onChange={(e) => setLoginUsername(e.target.value)}
                    placeholder="majidparismajid123"
                    className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 rounded-xl px-4 py-2.5 text-xs text-white outline-none transition"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5">كلمة المرور (Password)</label>
                  <input 
                    type="password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••••••••••"
                    className="w-full bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-xl px-4 py-2.5 text-xs text-white outline-none transition"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={isLoggingIn}
                  className="w-full py-3 bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white font-bold rounded-xl text-xs transition shadow-lg disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2"
                >
                  {isLoggingIn ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
                  تسجيل الدخول
                </button>
              </form>
            </div>
          ) : (
            /* ADMIN CONTROL PANEL ACTIVE */
            <div className="space-y-8">
              <div className="bg-gradient-to-r from-slate-900 via-sky-950/40 to-slate-900 p-6 rounded-3xl border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <ShieldCheck className="w-5 h-5 text-sky-400" />
                    <h2 className="text-xl font-extrabold text-white">
                      لوحة إدارة مباريات اليوم وروابط البث (Admin Panel)
                    </h2>
                  </div>
                  <p className="text-xs text-slate-400">
                    يمكنك هنا إضافة وإدارة جدول المباريات (اليوم / الغد / الأمس) وإدخال رابط البث HLS (.m3u8) لكل مباراة.
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={handleSaveAllToBackend}
                    disabled={isSavingAdmin}
                    className="px-5 py-2.5 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black shadow-lg flex items-center gap-2 transition disabled:opacity-50 cursor-pointer"
                  >
                    {isSavingAdmin ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                    حفظ ونشر الجدول للزوار
                  </button>
                  <button
                    onClick={handleResetDefaults}
                    disabled={isSavingAdmin}
                    className="px-4 py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs font-bold transition cursor-pointer"
                  >
                    إعادة التعيين الافتراضي
                  </button>
                  <button
                    onClick={handleAdminLogout}
                    className="p-2.5 rounded-2xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-bold transition cursor-pointer"
                    title="تسجيل الخروج"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Feedback Banner */}
              {adminMsg.text && (
                <div className={`p-4 rounded-2xl border text-xs font-bold flex items-center gap-2 ${
                  adminMsg.type === 'success' 
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                    : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                }`}>
                  <ShieldCheck className="w-4 h-4 shrink-0" />
                  <span>{adminMsg.text}</span>
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Form to Add / Edit Matches */}
                <div className="lg:col-span-5 bg-[#111726] p-6 rounded-3xl border border-slate-800 space-y-4">
                  <h3 className="text-base font-extrabold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
                    <Plus className="w-4 h-4 text-sky-400" />
                    {editingMatchId ? 'تعديل مباراة' : 'إضافة مباراة جديدة'}
                  </h3>

                  <form onSubmit={handleSaveMatchForm} className="space-y-4 text-xs">
                    {/* Teams */}
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-300 font-bold mb-1">الفريق المستضيف (Home)</label>
                        <input 
                          type="text"
                          placeholder="مثال: ريال مدريد"
                          value={formHomeTeam}
                          onChange={(e) => setFormHomeTeam(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 rounded-xl px-3 py-2 text-white outline-none"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-slate-300 font-bold mb-1">شعار المستضيف (Logo)</label>
                        <input 
                          type="url"
                          placeholder="http://...logo.png"
                          value={formHomeLogo}
                          onChange={(e) => setFormHomeLogo(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 rounded-xl px-3 py-2 text-white outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-300 font-bold mb-1">الفريق الضيف (Away)</label>
                        <input 
                          type="text"
                          placeholder="مثال: برشلونة"
                          value={formAwayTeam}
                          onChange={(e) => setFormAwayTeam(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 rounded-xl px-3 py-2 text-white outline-none"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-slate-300 font-bold mb-1">شعار الضيف (Logo)</label>
                        <input 
                          type="url"
                          placeholder="http://...logo.png"
                          value={formAwayLogo}
                          onChange={(e) => setFormAwayLogo(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 rounded-xl px-3 py-2 text-white outline-none"
                        />
                      </div>
                    </div>

                    {/* League & Date Tab */}
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-300 font-bold mb-1">تاريخ المباراة (اليوم/الغد)</label>
                        <select
                          value={formDateCategory}
                          onChange={(e) => setFormDateCategory(e.target.value as any)}
                          className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 rounded-xl px-3 py-2 text-white outline-none"
                        >
                          <option value="today">مباريات اليوم</option>
                          <option value="tomorrow">مباريات الغد</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-slate-300 font-bold mb-1">الدوري / البطولة</label>
                        <input 
                          type="text"
                          placeholder="الدوري الإسباني (La Liga)"
                          value={formLeague}
                          onChange={(e) => setFormLeague(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 rounded-xl px-3 py-2 text-white outline-none"
                        />
                      </div>
                    </div>

                    {/* Status & Scores */}
                    <div className="grid grid-cols-3 gap-3">
                      <div>
                        <label className="block text-slate-300 font-bold mb-1">الحالة</label>
                        <select
                          value={formStatus}
                          onChange={(e) => setFormStatus(e.target.value as any)}
                          className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 rounded-xl px-2 py-2 text-white outline-none"
                        >
                          <option value="LIVE">مباشر (LIVE)</option>
                          <option value="UPCOMING">قادمة (UPCOMING)</option>
                          <option value="FINISHED">انتهت (FINISHED)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-slate-300 font-bold mb-1">التوقيت / الدقيقة</label>
                        <input 
                          type="text"
                          placeholder="20:00 أو 65'"
                          value={formTime}
                          onChange={(e) => setFormTime(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 rounded-xl px-2 py-2 text-white outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-300 font-bold mb-1">النتيجة</label>
                        <div className="flex gap-1">
                          <input 
                            type="number" 
                            placeholder="0" 
                            value={formHomeScore}
                            onChange={(e) => setFormHomeScore(e.target.value)}
                            className="w-1/2 bg-slate-900 border border-slate-800 rounded-xl px-2 py-2 text-center text-white"
                          />
                          <input 
                            type="number" 
                            placeholder="0" 
                            value={formAwayScore}
                            onChange={(e) => setFormAwayScore(e.target.value)}
                            className="w-1/2 bg-slate-900 border border-slate-800 rounded-xl px-2 py-2 text-center text-white"
                          />
                        </div>
                      </div>
                    </div>

                    {/* HLS Stream Link */}
                    <div className="bg-slate-900/80 p-4 rounded-2xl border border-sky-900/40 space-y-2">
                      <label className="block text-sky-300 font-black flex items-center gap-1.5">
                        <Link2 className="w-4 h-4 text-sky-400" />
                        رابط البث المباشر HLS (.m3u8)
                      </label>
                      <input 
                        type="url"
                        placeholder="http://domain.com/live/stream1.m3u8"
                        value={formStreamUrl}
                        onChange={(e) => setFormStreamUrl(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-sky-500 rounded-xl px-3 py-2 text-white font-mono text-xs outline-none"
                      />
                    </div>

                    {/* Channel Name */}
                    <div>
                      <label className="block text-slate-300 font-bold mb-1">اسم القناة الناقلة</label>
                      <input 
                        type="text"
                        placeholder="beIN Sports HD1"
                        value={formChannelName}
                        onChange={(e) => setFormChannelName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 rounded-xl px-3 py-2 text-white outline-none"
                      />
                    </div>

                    {/* Submit Buttons */}
                    <div className="flex items-center gap-2 pt-2">
                      <button
                        type="submit"
                        className="flex-1 py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-sky-600/20"
                      >
                        {editingMatchId ? <Edit3 className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                        {editingMatchId ? 'تحديث هذه المباراة' : 'إضافة المباراة القائمة'}
                      </button>

                      {editingMatchId && (
                        <button
                          type="button"
                          onClick={resetForm}
                          className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition cursor-pointer"
                        >
                          إلغاء
                        </button>
                      )}
                    </div>
                  </form>
                </div>

                {/* Matches List */}
                <div className="lg:col-span-7 bg-[#111726] p-6 rounded-3xl border border-slate-800 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                    <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                      <Flame className="w-4 h-4 text-amber-500" />
                      جدول المباريات المضافة ({adminMatches.length})
                    </h3>
                    <span className="text-[11px] text-slate-400 font-medium">
                      💡 استخدم الأسهم (▲/▼) للترتيب أو زر (إخفاء) لإخفاء مباراة
                    </span>
                  </div>

                  {adminMatches.length === 0 ? (
                    <div className="py-16 text-center text-slate-500 text-xs">
                      لا توجد أي مباريات مضافة حالياً.
                    </div>
                  ) : (
                    <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
                      {adminMatches.map((match, idx) => (
                        <div 
                          key={match.id}
                          className={`p-4 rounded-2xl border transition flex flex-col gap-3 ${
                            editingMatchId === match.id 
                              ? 'bg-sky-950/40 border-sky-500' 
                              : match.hidden 
                                ? 'bg-slate-950/40 border-slate-800/80 opacity-75' 
                                : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center justify-between text-xs flex-wrap gap-2">
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-mono font-black text-sky-400 bg-sky-950 px-2 py-0.5 rounded border border-sky-800/60">
                                #{idx + 1}
                              </span>
                              <span className="font-bold text-sky-400">{match.league}</span>
                            </div>

                            <div className="flex items-center gap-2">
                              {match.hidden ? (
                                <span className="text-[10px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20 px-2 py-0.5 rounded flex items-center gap-1">
                                  <EyeOff className="w-3 h-3" />
                                  مخفي من الموقع
                                </span>
                              ) : (
                                <span className="text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded flex items-center gap-1">
                                  <Eye className="w-3 h-3" />
                                  ظاهر بالموقع
                                </span>
                              )}
                              <span className="text-[10px] bg-slate-950 text-slate-300 px-2 py-0.5 rounded font-bold border border-slate-800">
                                {match.dateCategory === 'tomorrow' ? 'الغد' : match.dateCategory === 'yesterday' ? 'الأمس' : 'اليوم'}
                              </span>
                              <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                                match.status === 'LIVE' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-slate-800 text-slate-400'
                              }`}>
                                {match.status === 'LIVE' ? `مباشر ${formatDisplayTime(match.time)}` : match.status}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center justify-between px-2">
                            <span className="text-xs font-extrabold text-white">{match.homeTeam}</span>
                            <span className="text-xs font-mono font-black text-sky-300">
                              {match.homeScore !== null ? `${match.homeScore} : ${match.awayScore}` : 'VS'}
                            </span>
                            <span className="text-xs font-extrabold text-white">{match.awayTeam}</span>
                          </div>

                          <div className="bg-slate-950 p-2 rounded-xl border border-slate-800 focus-within:border-sky-500 flex items-center justify-between gap-2 text-xs font-mono transition">
                            <span className="text-emerald-400 font-bold text-[10px] shrink-0 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">HLS Stream</span>
                            <input
                              type="text"
                              value={match.streamUrl || ''}
                              onChange={(e) => handleQuickStreamUrlChange(match.id, e.target.value)}
                              placeholder="أدخل رابط البث المباشر هنا..."
                              className="w-full bg-transparent text-slate-200 outline-none text-xs font-mono py-0.5 focus:text-white"
                            />
                          </div>

                          {/* Controls Row */}
                          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-800/60">
                            {/* Move Up/Down Order */}
                            <div className="flex items-center gap-1">
                              <span className="text-[10px] text-slate-400 font-semibold ml-1">الترتيب:</span>
                              <button
                                type="button"
                                onClick={() => handleMoveMatchUp(idx)}
                                disabled={idx === 0}
                                title="تقديم ترتيب المباراة للأعلى"
                                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800 text-slate-200 transition cursor-pointer"
                              >
                                <ArrowUp className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleMoveMatchDown(idx)}
                                disabled={idx === adminMatches.length - 1}
                                title="تأخير ترتيب المباراة للأسفل"
                                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800 text-slate-200 transition cursor-pointer"
                              >
                                <ArrowDown className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            {/* Hide / Edit / Delete / Preview */}
                            <div className="flex flex-wrap items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => handleToggleHideMatch(match.id)}
                                className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition flex items-center gap-1 cursor-pointer border ${
                                  match.hidden 
                                    ? 'bg-rose-950/60 hover:bg-rose-900 text-rose-300 border-rose-800' 
                                    : 'bg-emerald-950/60 hover:bg-emerald-900 text-emerald-300 border-emerald-800'
                                }`}
                              >
                                {match.hidden ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                                {match.hidden ? 'إظهار بالموقع' : 'إخفاء من الموقع'}
                              </button>

                              <button
                                type="button"
                                onClick={() => handleSelectMatch(match)}
                                className="px-2.5 py-1 rounded-xl bg-sky-600/20 hover:bg-sky-600 text-sky-300 hover:text-white border border-sky-500/30 text-[11px] font-bold transition flex items-center gap-1 cursor-pointer"
                              >
                                <Play className="w-3 h-3 fill-current" />
                                معاينة
                              </button>
                              <button
                                type="button"
                                onClick={() => handleEditMatchClick(match)}
                                className="px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-[11px] font-bold transition flex items-center gap-1 cursor-pointer"
                              >
                                <Edit3 className="w-3 h-3" />
                                تعديل
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteMatchClick(match.id)}
                                className="px-2.5 py-1 rounded-xl bg-rose-950/40 hover:bg-rose-900 text-rose-300 border border-rose-800 text-[11px] font-bold transition flex items-center gap-1 cursor-pointer"
                              >
                                <Trash2 className="w-3 h-3" />
                                حذف
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </main>
      ) : currentRoute === 'match' && activeMatch ? (
        /* DEDICATED FULL STREAM PAGE VIEW */
        <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
          
          {/* Top Breadcrumb & Return Header */}
          <div className="flex items-center justify-between bg-[#111726] p-4 rounded-2xl border border-slate-800">
            <button 
              onClick={() => navigateTo('public')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-850 text-sky-300 text-xs font-bold transition cursor-pointer border border-slate-800"
            >
              <ChevronRight className="w-4 h-4" />
              العودة إلى قائمة المباريات
            </button>

            <div className="flex items-center gap-3">
              <span className="text-xs font-extrabold text-white hidden sm:inline">
                {activeMatch.league}
              </span>
              <span className={`text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1.5 ${
                activeMatch.status === 'LIVE' 
                  ? 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20'
                  : activeMatch.status === 'FINISHED'
                    ? 'text-slate-400 bg-slate-900 border border-slate-800'
                    : 'text-sky-300 bg-sky-500/10 border border-sky-500/20'
              }`}>
                {activeMatch.status === 'LIVE' ? (
                  <>
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    مباشر {activeMatch.time && activeMatch.time !== 'مباشر' && activeMatch.time !== 'لم تبدأ' && !activeMatch.time.includes('نتيجة') ? `(${activeMatch.time})` : ''}
                  </>
                ) : activeMatch.status === 'FINISHED' ? (
                  'انتهت المباراة'
                ) : (
                  <>
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    لم تبدأ {activeMatch.time && activeMatch.time !== 'لم تبدأ' ? `(${activeMatch.time})` : ''}
                  </>
                )}
              </span>
            </div>
          </div>

          {/* Match Scoreboard Header Banner */}
          <div className="bg-gradient-to-r from-slate-900 via-[#111c33] to-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
              
              {/* Home Team */}
              <div className="flex items-center gap-4 w-full md:w-5/12 justify-center md:justify-start">
                <div className="w-14 h-14 rounded-full bg-slate-950 p-2 border border-slate-800 shadow-lg flex items-center justify-center shrink-0">
                  {activeMatch.homeLogo ? (
                    <img src={activeMatch.homeLogo} alt={activeMatch.homeTeam} className="w-full h-full object-contain" />
                  ) : (
                    <div className={`w-full h-full rounded-full bg-gradient-to-tr ${getInitialsColor(activeMatch.homeTeam)} text-white font-black text-sm flex items-center justify-center`}>
                      {getInitials(activeMatch.homeTeam)}
                    </div>
                  )}
                </div>
                <h2 className="text-lg sm:text-xl font-black text-white text-center md:text-right">
                  {activeMatch.homeTeam}
                </h2>
              </div>

              {/* Score / VS Center */}
              <div className="flex flex-col items-center justify-center shrink-0 bg-slate-950/90 border border-slate-800 px-6 py-3.5 rounded-2xl min-w-[130px]">
                {activeMatch.status === 'UPCOMING' && activeMatch.homeScore === null ? (
                  <div className="flex flex-col items-center">
                    <span className="text-lg font-black text-amber-400 font-mono tracking-wider">
                      {activeMatch.time || 'لم تبدأ'}
                    </span>
                  </div>
                ) : (
                  <div className="flex items-center gap-3 font-mono">
                    <span className="text-2xl sm:text-3xl font-black text-white">
                      {activeMatch.homeScore !== null && activeMatch.homeScore !== undefined ? activeMatch.homeScore : 0}
                    </span>
                    <span className="text-base text-sky-400 font-extrabold">:</span>
                    <span className="text-2xl sm:text-3xl font-black text-white">
                      {activeMatch.awayScore !== null && activeMatch.awayScore !== undefined ? activeMatch.awayScore : 0}
                    </span>
                  </div>
                )}
                <span className="text-[10px] font-bold text-slate-400 mt-1">
                  {activeMatch.channelName || 'beIN Sports HD1'}
                </span>
              </div>

              {/* Away Team */}
              <div className="flex items-center gap-4 w-full md:w-5/12 justify-center md:justify-end">
                <h2 className="text-lg sm:text-xl font-black text-white text-center md:text-left order-2 md:order-1">
                  {activeMatch.awayTeam}
                </h2>
                <div className="w-14 h-14 rounded-full bg-slate-950 p-2 border border-slate-800 shadow-lg flex items-center justify-center shrink-0 order-1 md:order-2">
                  {activeMatch.awayLogo ? (
                    <img src={activeMatch.awayLogo} alt={activeMatch.awayTeam} className="w-full h-full object-contain" />
                  ) : (
                    <div className={`w-full h-full rounded-full bg-gradient-to-tr ${getInitialsColor(activeMatch.awayTeam)} text-white font-black text-sm flex items-center justify-center`}>
                      {getInitials(activeMatch.awayTeam)}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* DEDICATED STREAM VIDEO STAGE */}
          <div className="bg-[#111726] border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col relative">
            
            <div className="relative aspect-video bg-black flex items-center justify-center">
              <video 
                ref={videoRef}
                className="w-full h-full object-contain"
                playsInline
                crossOrigin="anonymous"
                onClick={togglePlay}
              />

              {/* Stream Error */}
              {streamError && (
                <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center p-6 text-center z-20 space-y-3">
                  <AlertTriangle className="w-12 h-12 text-rose-500 animate-bounce" />
                  <h3 className="text-base font-extrabold text-white">تعذر اتصال السيرفر بالبث حالياً</h3>
                  <p className="text-xs text-slate-400 max-w-md">{streamError}</p>
                  <button 
                    onClick={() => {
                      if (currentStreamUrl) {
                        const stream = currentStreamUrl;
                        setCurrentStreamUrl('');
                        setTimeout(() => setCurrentStreamUrl(stream), 100);
                      }
                    }}
                    className="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-lg"
                  >
                    إعادة تجربة البث
                  </button>
                </div>
              )}

              {/* Loading */}
              {isLoadingStream && (
                <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center gap-3 z-10">
                  <RefreshCw className="w-10 h-10 text-sky-500 animate-spin" />
                  <p className="text-xs font-bold text-white">جاري الاتصال بسيرفر البث المباشر HLS...</p>
                </div>
              )}

              {/* Video controls */}
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/90 to-transparent flex items-center justify-between opacity-0 hover:opacity-100 transition duration-200">
                <div className="flex items-center gap-3">
                  <button onClick={togglePlay} className="p-2 text-white bg-white/10 rounded-lg hover:bg-white/20 transition">
                    {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-white" />}
                  </button>
                  <button onClick={toggleMute} className="p-2 text-white bg-white/10 rounded-lg hover:bg-white/20 transition">
                    {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                </div>

                <button onClick={toggleFullscreen} className="p-2 text-white bg-white/10 rounded-lg hover:bg-white/20 transition">
                  <Maximize className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Video Footer & Server Quality Selectors */}
            <div className="p-4 bg-slate-950 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-300">سيرفرات وجودة البث:</span>
                <div className="flex items-center gap-2">
                  {['FHD 1080p', 'HD 720p', 'SD 480p'].map((q) => (
                    <button
                      key={q}
                      onClick={() => setActiveQuality(q)}
                      className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer ${
                        activeQuality === q
                          ? 'bg-sky-600 text-white shadow-md'
                          : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-850'
                      }`}
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-4 text-xs text-slate-400">
                <span className="flex items-center gap-1.5">
                  <Tv className="w-4 h-4 text-sky-400" />
                  القناة: <strong className="text-white">{activeMatch.channelName || 'beIN Sports HD1'}</strong>
                </span>
                <span className="flex items-center gap-1.5">
                  <Globe className="w-4 h-4 text-emerald-400" />
                  حالة البث: <strong className="text-emerald-400">مباشر ممتازة</strong>
                </span>
              </div>
            </div>
          </div>

          {/* Related / Other Matches */}
          <div className="bg-[#111726] border border-slate-800 rounded-3xl p-6 space-y-4">
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <Flame className="w-4 h-4 text-amber-500" />
              مباريات أخرى جارية الآن
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {matches
                .filter(m => m.id !== activeMatch.id)
                .slice(0, 4)
                .map((m) => (
                  <div 
                    key={m.id}
                    onClick={() => handleSelectMatch(m)}
                    className="p-4 rounded-2xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800 hover:border-sky-500/40 transition cursor-pointer flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div className="text-xs font-bold text-white">
                        {m.homeTeam} <span className="text-sky-400 font-mono">VS</span> {m.awayTeam}
                      </div>
                    </div>
                    <span className="text-[11px] font-bold text-sky-300 bg-sky-950/60 px-2.5 py-1 rounded-xl border border-sky-800/40 flex items-center gap-1">
                      <Play className="w-3 h-3 fill-current" />
                      بث مباشر
                    </span>
                  </div>
                ))}
            </div>
          </div>
        </main>
      ) : (
        /* PUBLIC MAIN SITE PAGE (Matched Exactly to User Screenshot UI) */
        <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-8">
          
          {/* Top Welcome Cards Section */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch">
            
            {/* Majid TV Card matching uploaded image */}
            <div className="md:col-span-7 relative p-6 sm:p-8 rounded-2xl bg-gradient-to-b from-[#163561] via-[#0f274a] to-[#0a1b36] border border-[#234f8a] shadow-[0_0_30px_rgba(15,39,74,0.6)] flex flex-col items-center justify-center overflow-hidden min-h-[200px]">
              {/* Inner glossy border frame matching screenshot */}
              <div className="absolute inset-2.5 rounded-[16px] border border-[#2c5b9e]/50 pointer-events-none" />
              <div className="absolute -top-12 -right-12 w-32 h-32 bg-sky-500/10 rounded-full blur-2xl pointer-events-none" />
              
              {/* Signal & Play Button */}
              <div className="flex items-center justify-center gap-1.5 mb-2 z-10">
                <span className="text-sky-200/70 font-mono text-sm font-bold tracking-tighter">((</span>
                <div className="w-7 h-7 rounded-full bg-[#1b3d6f]/80 backdrop-blur-md border border-sky-300/40 flex items-center justify-center shadow-md">
                  <Play className="w-3.5 h-3.5 text-white fill-white ml-0.5" />
                </div>
                <span className="text-sky-200/70 font-mono text-sm font-bold tracking-tighter">))</span>
              </div>

              {/* majid tv Logo */}
              <h2 className="text-4xl sm:text-5xl font-black text-white tracking-tight font-sans drop-shadow-md z-10">
                majid tv
              </h2>

              {/* مجيد تي في Subtitle */}
              <p className="text-xl sm:text-2xl font-black text-white mt-1 tracking-wide drop-shadow-md z-10">
                مجيد تي في
              </p>
            </div>

            {/* Sub Welcome Info Card */}
            <div className="md:col-span-5 bg-[#111726] border border-slate-800 rounded-3xl p-6 flex flex-col justify-center text-right relative overflow-hidden">
              <div className="border-r-4 border-cyan-400 pr-4 space-y-2">
                <h3 className="text-lg font-black text-white">
                  مرحباً بكم في <span className="text-cyan-400">مجيد تي في (majid tv)</span>
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  استكشف أشهر الدوريات والبطولات العالمية في مكان واحد. تابع أخبار المنافسات، جدول المباريات، النتائج المباشرة وأبرز الأحداث.
                </p>
              </div>
            </div>
          </div>

          {/* Major Leagues Navigation Selector Bar */}
          <div className="bg-[#111726] border border-slate-800 rounded-3xl p-4 shadow-md space-y-3">
            <div className="flex items-center justify-between px-1">
              <div className="flex items-center gap-2">
                <Trophy className="w-4 h-4 text-amber-400 shrink-0" />
                <h3 className="text-sm font-black text-white">الدوريات الخمس الكبرى والبطولات:</h3>
              </div>
              {selectedLeague !== 'all' && (
                <button
                  type="button"
                  onClick={() => setSelectedLeague('all')}
                  className="text-xs font-bold text-sky-400 hover:text-sky-300 underline cursor-pointer"
                >
                  عرض جميع البطولات
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5">
              {MAJOR_LEAGUES.map((lg) => {
                const isSelected = selectedLeague === lg.id;
                return (
                  <button
                    key={lg.id}
                    type="button"
                    onClick={() => setSelectedLeague(lg.id)}
                    className={`flex items-center gap-2.5 p-2.5 rounded-2xl border transition text-right cursor-pointer group ${
                      isSelected
                        ? 'bg-gradient-to-r from-sky-600 via-blue-600 to-sky-600 border-sky-400 text-white shadow-lg shadow-sky-600/30'
                        : 'bg-slate-900/80 hover:bg-slate-850 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-full bg-white/10 border border-white/20 p-1 flex items-center justify-center shrink-0 shadow-inner overflow-hidden">
                      {lg.isEmoji ? (
                        <span className="text-sm">{lg.logo}</span>
                      ) : (
                        <img
                          src={lg.logo}
                          alt={lg.name}
                          className="w-full h-full object-contain"
                          onError={(e) => { e.currentTarget.style.display = 'none'; }}
                        />
                      )}
                    </div>
                    <div className="flex flex-col overflow-hidden">
                      <span className="text-[11px] font-black truncate">{lg.name}</span>
                      <span className={`text-[9px] truncate ${isSelected ? 'text-sky-100' : 'text-slate-400'}`}>
                        {lg.nameEn}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* MAIN CONTENT AREA */}
          <div className="space-y-6">
            
            {/* Date Filter Tabs Bar (مباشر / اليوم / الغد) */}
              <div className="bg-[#111726] border border-slate-800 p-2 rounded-2xl grid grid-cols-3 gap-2 text-center text-sm font-bold">
                <button
                  type="button"
                  onClick={() => setActiveDayTab('live')}
                  className={`py-3 rounded-xl transition cursor-pointer flex items-center justify-center gap-2 ${
                    activeDayTab === 'live'
                      ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-600/30'
                      : 'bg-slate-900/60 hover:bg-slate-850 text-slate-300'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  مباشر
                </button>

                <button
                  type="button"
                  onClick={() => setActiveDayTab('today')}
                  className={`py-3 rounded-xl transition cursor-pointer ${
                    activeDayTab === 'today'
                      ? 'bg-gradient-to-r from-sky-600 via-blue-600 to-sky-600 text-white shadow-lg shadow-sky-600/30 font-black'
                      : 'bg-slate-900/60 hover:bg-slate-850 text-slate-300'
                  }`}
                >
                  اليوم
                </button>

                <button
                  type="button"
                  onClick={() => setActiveDayTab('tomorrow')}
                  className={`py-3 rounded-xl transition cursor-pointer ${
                    activeDayTab === 'tomorrow'
                      ? 'bg-gradient-to-r from-sky-600 via-blue-600 to-sky-600 text-white shadow-lg shadow-sky-600/30 font-black'
                      : 'bg-slate-900/60 hover:bg-slate-850 text-slate-300'
                  }`}
                >
                  الغد
                </button>
              </div>

              {/* Section Banner Header */}
              <div className="bg-gradient-to-r from-sky-600 via-blue-600 to-sky-600 rounded-2xl py-3.5 px-6 text-center shadow-lg shadow-sky-600/20">
                <h3 className="text-lg font-black text-white">
                  {activeDayTab === 'live' ? 'المباريات المباشرة الآن 🔥' : activeDayTab === 'tomorrow' ? 'مباريات الغد 📅' : 'مباريات اليوم ⚽'}
                  {selectedLeague !== 'all' && ` - ${MAJOR_LEAGUES.find(l => l.id === selectedLeague)?.name}`}
                </h3>
              </div>

              {/* MATCHES LIST / GRID */}
              <div className="bg-[#111726] rounded-3xl p-6 border border-slate-800 min-h-[300px]">
                {isLoadingMatches ? (
                  <div className="py-20 flex flex-col items-center justify-center gap-3 text-slate-400">
                    <RefreshCw className="w-8 h-8 animate-spin text-sky-500" />
                    <p className="text-xs font-bold">جاري تحميل جدول المباريات المباشرة...</p>
                  </div>
                ) : matchesError ? (
                  <div className="py-16 text-center text-rose-400 text-xs font-bold flex flex-col items-center gap-2">
                    <AlertTriangle className="w-8 h-8" />
                    <span>{matchesError}</span>
                    <button type="button" onClick={() => fetchMatches(true)} className="mt-2 text-sky-400 underline cursor-pointer">
                      إعادة المحاولة
                    </button>
                  </div>
                ) : (() => {
                  const filteredList = getFilteredMatches();
                  if (filteredList.length === 0) {
                    return (
                      <div className="py-16 text-center text-slate-400 text-xs font-medium">
                        لا توجد مباريات حالياً في هذا القسم.
                      </div>
                    );
                  }

                  return (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {filteredList.map((match) => (
                        <div 
                          key={match.id}
                          onClick={() => handleSelectMatch(match)}
                          className={`p-5 rounded-2xl transition cursor-pointer border flex flex-col justify-between min-h-[160px] relative overflow-hidden group ${
                            activeMatch?.id === match.id
                              ? 'bg-sky-950/40 border-sky-500 shadow-xl shadow-sky-500/10'
                              : 'bg-slate-900/60 hover:bg-slate-900 border-slate-800 hover:border-sky-500/40'
                          }`}
                        >
                          {/* Header League */}
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-1.5 truncate max-w-[70%]">
                              {getLeagueLogo(match.league) && (
                                <img src={getLeagueLogo(match.league)!} alt="" className="w-4 h-4 object-contain shrink-0" />
                              )}
                              <span className="text-xs font-extrabold text-sky-300 truncate">
                                {match.league}
                              </span>
                            </div>
                            {match.status === 'LIVE' ? (
                              <span className="flex items-center gap-1 text-[10px] font-black text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20 shrink-0">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                                مباشر {match.time && match.time !== 'مباشر' && match.time !== 'لم تبدأ' && !match.time.includes('نتيجة') ? `(${match.time})` : ''}
                              </span>
                            ) : match.status === 'FINISHED' ? (
                              <span className="text-[10px] font-semibold text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                                انتهت
                              </span>
                            ) : null}
                          </div>

                          {/* Teams & Scores */}
                          <div className="flex items-center justify-between my-3">
                            {/* Home */}
                            <div className="flex items-center gap-3 w-[42%]">
                              <div className="relative shrink-0">
                                {match.homeLogo ? (
                                  <img 
                                    src={match.homeLogo} 
                                    alt={match.homeTeam}
                                    className="w-9 h-9 rounded-full object-contain p-1 border border-slate-800 bg-slate-950"
                                    onError={(e) => {
                                      e.currentTarget.style.display = 'none';
                                      const fb = e.currentTarget.nextElementSibling as HTMLElement;
                                      if (fb) fb.style.display = 'flex';
                                    }}
                                  />
                                ) : null}
                                <div 
                                  style={{ display: match.homeLogo ? 'none' : 'flex' }}
                                  className={`w-9 h-9 rounded-full bg-gradient-to-tr ${getInitialsColor(match.homeTeam)} text-white font-black text-xs flex items-center justify-center border border-slate-800`}
                                >
                                  {getInitials(match.homeTeam)}
                                </div>
                              </div>
                              <span className="text-xs font-bold text-white truncate text-right">
                                {match.homeTeam}
                              </span>
                            </div>

                            {/* Score */}
                            <div className="flex flex-col items-center justify-center px-3 py-1.5 rounded-xl border border-slate-800 bg-slate-950 font-mono min-w-[70px]">
                              {match.status === 'UPCOMING' && match.homeScore === null ? (
                                <div className="flex flex-col items-center">
                                  <span className="text-xs font-black text-amber-400">
                                    {match.time || 'لم تبدأ'}
                                  </span>
                                </div>
                              ) : (
                                <div className="flex items-center">
                                  <span className="text-sm font-black text-white">
                                    {match.homeScore !== null && match.homeScore !== undefined ? match.homeScore : 0}
                                  </span>
                                  <span className="text-xs text-slate-500 mx-1.5">:</span>
                                  <span className="text-sm font-black text-white">
                                    {match.awayScore !== null && match.awayScore !== undefined ? match.awayScore : 0}
                                  </span>
                                </div>
                              )}
                            </div>

                            {/* Away */}
                            <div className="flex items-center gap-3 w-[42%] justify-end text-left">
                              <span className="text-xs font-bold text-white truncate">
                                {match.awayTeam}
                              </span>
                              <div className="relative shrink-0">
                                {match.awayLogo ? (
                                  <img 
                                    src={match.awayLogo} 
                                    alt={match.awayTeam}
                                    className="w-9 h-9 rounded-full object-contain p-1 border border-slate-800 bg-slate-950"
                                    onError={(e) => {
                                      e.currentTarget.style.display = 'none';
                                      const fb = e.currentTarget.nextElementSibling as HTMLElement;
                                      if (fb) fb.style.display = 'flex';
                                    }}
                                  />
                                ) : null}
                                <div 
                                  style={{ display: match.awayLogo ? 'none' : 'flex' }}
                                  className={`w-9 h-9 rounded-full bg-gradient-to-tr ${getInitialsColor(match.awayTeam)} text-white font-black text-xs flex items-center justify-center border border-slate-800`}
                                >
                                  {getInitials(match.awayTeam)}
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Footer */}
                          <div className="border-t border-slate-800/80 pt-2.5 flex items-center justify-center">
                            <span className="w-full text-center text-[11px] font-black py-2 rounded-xl bg-sky-600 group-hover:bg-sky-500 text-white transition flex items-center justify-center gap-1.5 shadow-md shadow-sky-600/20">
                              <Play className="w-3 h-3 fill-white" />
                              مشاهدة البث
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  );
                })()}
              </div>
          </div>
        </main>
      )}



      {/* FOOTER */}
      <footer className="mt-auto border-t border-slate-800 bg-[#090d16] py-8 text-center text-xs text-slate-500 space-y-4">
        {/* Contact section */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5 text-xs text-slate-300 bg-slate-900/80 w-fit mx-auto px-5 py-2.5 rounded-2xl border border-slate-800 shadow-md">
          <div className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-sky-400" />
            <span className="font-bold text-white">للتواصل معي:</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-sky-300 font-bold select-all dir-ltr">majidtv@outlook.fr</span>
            <button 
              type="button"
              onClick={handleCopyEmail} 
              className="px-2.5 py-1 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-[11px] font-bold transition flex items-center gap-1 cursor-pointer shadow-sm"
            >
              {emailCopied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-300" />
                  تم النسخ!
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  نسخ الإيميل
                </>
              )}
            </button>
          </div>
        </div>

        <p className="font-bold text-slate-400">
          Majid Live TV © 2026 جميع الحقوق محفوظة
        </p>
        <div className="flex flex-wrap justify-center gap-4 text-[11px] text-slate-400">
          <a href="#" className="hover:text-sky-400 transition">سياسة الخصوصية</a>
          <a href="#" className="hover:text-sky-400 transition">شروط الاستخدام</a>
          <a href="#" className="hover:text-sky-400 transition">اتصل بنا</a>
          <a href="#" className="hover:text-sky-400 transition">DMCA</a>
          <a href="#" className="hover:text-sky-400 transition">من نحن</a>
        </div>
      </footer>
    </div>
  );
}
