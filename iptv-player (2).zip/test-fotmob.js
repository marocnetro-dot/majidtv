async function test() {
  const dates = ["20241010", "2024-10-10", "20260719"];
  for (const date of dates) {
    const url = `https://www.fotmob.com/api/matches?date=${date}&timezone=Africa/Casablanca`;
    try {
      const res = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/json, text/plain, */*'
        }
      });
      console.log(`Date: ${date} -> Status: ${res.status}`);
      const text = await res.text();
      console.log(`Length: ${text.length}`);
      if (res.status === 200) {
        console.log("Response starts with:", text.substring(0, 100));
      }
    } catch (e) {
      console.error(`Error for date ${date}:`, e);
    }
  }
}
test();
